"""Global sensitivity analysis: Latin hypercube over uncertain parameters, R reps per set."""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import des_sim as ds

RANGES = dict(s=(0.0, 0.9), q_b=(0.6, 0.95), q_f=(0.0, 0.3), p_day=(0.6, 0.95), p_night=(0.2, 0.8),
              A=(1.0, 10.0), F=(15.0, 60.0), W_day=(30.0, 180.0), C=(30.0, 60.0), S_b=(10.0, 40.0),
              S_f=(30.0, 90.0), c=(0.5, 4.5), lam=(0.1, 0.4))


def design(n, seed=7):
    from scipy.stats import qmc
    u = qmc.LatinHypercube(d=len(RANGES), seed=seed).random(n)
    df = pd.DataFrame({k: lo + u[:, i] * (hi - lo) for i, (k, (lo, hi)) in enumerate(RANGES.items())})
    df["c"] = np.clip(np.round(df.c), 1, 4).astype(int)
    return df


def paired_set_differences(G):
    """Per set: mean and Monte Carlo SE of the per-replication paired differences S2 - S1."""
    out = {}
    for y in ["long_lie60", "ll60_device"]:
        w = G.pivot_table(index=["set", "rep"], columns="scenario", values=y)
        d = (w["S2"] - w["S1"]).groupby("set")
        out[y] = pd.DataFrame({"mean": d.mean(), "se": d.std() / np.sqrt(d.count()), "n": d.count()})
    return out


def indeterminate_sets(folder, k=2.0):
    import glob
    G = pd.concat([pd.read_parquet(f) for f in glob.glob(f"{folder}/*.parquet")], ignore_index=True)
    D = paired_set_differences(G)
    m = np.zeros(len(D["long_lie60"]), bool)
    for y in D:
        m |= (D[y]["mean"].abs() < k * D[y]["se"]).values
    return [int(i) for i in D["long_lie60"].index[m]]


if __name__ == "__main__":
    # usage: python src/gsa.py <set0> <set1> <rep1> [rep0]   (replications rep0..rep1-1 of each set)
    i0, i1, R = int(sys.argv[1]), int(sys.argv[2]), int(sys.argv[3])
    R0 = int(sys.argv[4]) if len(sys.argv) > 4 else 0
    sets = [int(x) for x in sys.argv[5].split(",")] if len(sys.argv) > 5 else list(range(i0, i1))
    D = pd.read_csv("results/gsa_design.csv")
    homes, eval_len, ben, fl, dl = ds.load_inputs("data/derived", ["generic", "personal"])
    rows = []
    for i in sets:
        P = dict(ds.BASE); P.update({k: (int(v) if k == "c" else float(v)) for k, v in D.iloc[i].items()})
        P["F_sd"] = P["F"] / 2
        for rep in range(R0, R):
            rng = np.random.default_rng([99, i, rep])
            cat = ds.Catchment(ben, fl, eval_len, homes, P, rng, dl)
            for s in ["S0", "S1", "S2"]:
                res, _, _ = ds.run_scenario(cat, P, s); res.pop("_per_home", None)
                res.update(set=i, rep=rep, scenario=s); rows.append(res)
    os.makedirs("results/gsa", exist_ok=True)
    tag = f"gsa_{i0:04d}" if R0 == 0 else f"gsa_{i0:04d}_r{R0:03d}"
    pd.DataFrame(rows).to_parquet(f"results/gsa/{tag}.parquet", index=False)
