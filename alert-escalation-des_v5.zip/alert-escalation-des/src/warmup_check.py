
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import des_sim as ds
r0, r1 = int(sys.argv[1]), int(sys.argv[2])
SC = ["S1", "S2", "S2-noTier", "S2-noAdapt", "S2-noVerify"]
WARM = [0, 14, 30]
homes, eval_len, ben, fl, dl = ds.load_inputs("data/derived", ["generic", "personal"])
P = dict(ds.BASE); P["_return_raw"] = True
H = P["horizon_days"]; DAY = 1440.0
rows, weekly = [], []
for rep in range(r0, r1):
    rng = np.random.default_rng([20261116, rep])          # same seeds as the main fixed-home experiment
    cat = ds.Catchment(ben, fl, eval_len, homes, P, rng, dl)
    for s in SC:
        res, _, _ = ds.run_scenario(cat, P, s); R = res["_raw"]
        nb = R["nb"]; t_b = R["t0"][:nb]; req = R["req"]; wait = R["wait"]; st = R["start"]; sv = R["serv"]
        rq_b = R["rq"][:nb]
        for W in WARM:
            w0 = W * DAY; hd = R["n_homes"] * (H - W)
            mb = t_b >= w0; mf = R["t_f"] >= w0; mr = req >= w0
            fh = R["fall_help"][mf]; dv = R["dev"][mf]
            busy = np.clip(np.minimum(st + sv, H * DAY) - np.maximum(st, w0), 0, None).sum() if len(st) else 0.0
            rows.append(dict(rep=rep, scenario=s, warm=W,
                long_lie60=float(np.mean(fh >= 60)), ll60_device=float(np.mean(fh[dv] >= 60)) if dv.any() else np.nan,
                help_med_device=float(np.median(fh[dv])) if dv.any() else np.nan,
                fam_notif_per100=100 * R["fam_notified"][mb].sum() / hd,
                fam_notif_night_per100=100 * (R["fam_notified"] & R["night_b"])[mb].sum() / hd,
                resp_callout_per100=100 * (rq_b & mb).sum() / hd,
                resp_util=busy / (P["c"] * (H - W) * DAY),
                resp_wait_mean=float(wait[mr].mean()) if mr.any() else 0.0,
                resp_wait_p95=float(np.percentile(wait[mr], 95)) if mr.any() else 0.0))
        if len(req):
            wk = np.minimum((req // (7 * DAY)).astype(int), 52)
            g = pd.DataFrame({"week": wk, "wait": wait}).groupby("week").wait.agg(["mean", "size"]).reset_index()
            g["rep"] = rep; g["scenario"] = s; weekly.append(g)
os.makedirs("results/warmup", exist_ok=True)
pd.DataFrame(rows).to_parquet(f"results/warmup/metrics_{r0:05d}.parquet", index=False)
pd.concat(weekly).to_parquet(f"results/warmup/weekly_{r0:05d}.parquet", index=False)
