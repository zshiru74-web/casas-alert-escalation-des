
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import des_sim as ds
r0, r1 = int(sys.argv[1]), int(sys.argv[2])
SC = ["S0", "S1", "S2", "S2-noVerify", "S2-noEscalate", "S2-noTier", "S2-noAdapt"]
# informal discovery: exponential, calibrated so that P(T >= 60 min) = target
TARGETS = {"none": None, "p33": 0.33, "p49": 0.49}
MU = {k: (None if v is None else 60.0 / np.log(1.0 / v)) for k, v in TARGETS.items()}
homes, eval_len, ben, fl, dl = ds.load_inputs("data/derived", ["generic", "personal"])
P = dict(ds.BASE); P["_return_raw"] = True
rows = []
for rep in range(r0, r1):
    rng = np.random.default_rng([20261116, rep])
    cat = ds.Catchment(ben, fl, eval_len, homes, P, rng, dl)
    u = np.random.default_rng([777, rep]).random(len(cat.falls))     # common across scenarios
    for s in SC:
        res, fh, dev = ds.run_scenario(cat, P, s)
        for k, mu in MU.items():
            h = fh if mu is None else np.minimum(fh, -mu * np.log(u))
            rows.append(dict(rep=rep, scenario=s, informal=k, n=len(h), ll60=int((h >= 60).sum()), ll120=int((h >= 120).sum()),
                             n_dev=int(dev.sum()), ll60_dev=int((h[dev] >= 60).sum()), ll60_amb=int((h[~dev] >= 60).sum()),
                             med=float(np.median(h)) if len(h) else np.nan))
os.makedirs("results/informal", exist_ok=True)
pd.DataFrame(rows).to_parquet(f"results/informal/metrics_{r0:05d}.parquet", index=False)
