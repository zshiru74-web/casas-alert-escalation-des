"""Step 6. Summary tables (Tables 3-5, sensitivity analyses, validation) and data for Figures 3 and 5.

Outputs (results/): table_main_results.csv, table_paired_differences.csv, main_fixed_home_bootstrap.csv,
responder_accounting.csv, mc_standard_errors.csv, between_catchment_variation.csv, staffing_paired_comparisons.csv,
table_S2_model_checks.csv, table_S3_schedule_checks.csv, table_S4_between_catchment.csv, gsa_direction_counts.csv, decomposition_main.csv, decomposition_staffing.csv,
main_fixed_paired_differences.csv, main_boot_summary.csv, sweep_*.csv, detection_sensitivity.csv,
gsa_set_level.csv, gsa_prcc.csv, informal_pooled.csv, informal_paired_differences.csv,
warmup_paired_differences.csv, extra_offsets.csv, extra_fall_overlap.csv, table_staffing.csv,
table_home_inclusion.csv, fig3a_alerts_by_hour.csv, fig3b_dispatch_by_hour.csv, fig5_timeline_examples.csv
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import glob, json, os, re
import numpy as np, pandas as pd
from scipy import stats
import _common  # noqa: F401
import des_sim as ds

meta = json.load(open("data/derived/meta.json")); HOMES = meta["homes"]; EVAL = meta["eval_len"]; EVD = sum(EVAL.values())


def load(exp, kind="metrics"):
    return pd.concat([pd.read_parquet(f) for f in sorted(glob.glob(f"results/{exp}/{kind}_*.parquet"))], ignore_index=True)


# ---------------------------------------------------------------- main experiment (Table 3)
mb = load("main_boot"); mf = load("main_fixed")
METRICS = ["long_lie60", "ll60_device", "long_lie120", "help_median", "help_med_device", "alerts_per100", "fam_notif_per100",
           "fam_notif_night_per100", "fam_visit_per100", "resp_callout_per100", "resp_util", "resp_wait_mean", "resp_wait_p95", "init15"]
SC = ["S0-fixedRule", "S1-fixedRule", "S0", "S1", "S2", "S2-noVerify", "S2-noEscalate", "S2-noTier", "S2-noAdapt"]
g = mb.groupby("scenario")[METRICS]
SYS = pd.concat({"mean": g.mean(), "lo": g.quantile(.025), "hi": g.quantile(.975)}, axis=1)
SYS.to_csv("results/main_boot_summary.csv")

ph = load("main_fixed", "perhome")
agg = ph.groupby(["scenario", "home"])[["n_alert", "fam", "fam_night", "fam_visit", "callout", "att_b", "n_fall", "ll60", "ll120", "dev", "ll60_dev",
                                       "disp_f", "att_f", "home_days"]].sum()
agg["disp_all"] = agg.callout + agg.disp_f; agg["att_all"] = agg.att_b + agg.att_f   # all dispatches; in-year attendances
agg["ll60_r"] = agg.ll60 / agg.n_fall; agg["ll120_r"] = agg.ll120 / agg.n_fall; agg["ll60dev_r"] = agg.ll60_dev / agg.dev
agg["ll60amb_r"] = (agg.ll60 - agg.ll60_dev) / (agg.n_fall - agg.dev)
for k in ["n_alert", "fam", "fam_night", "fam_visit", "callout", "disp_all", "att_all"]:
    agg[k + "_100"] = 100 * agg[k] / agg.home_days
HM = ["ll60_r", "ll60dev_r", "ll60amb_r", "ll120_r", "n_alert_100", "fam_100", "fam_night_100", "fam_visit_100", "callout_100", "disp_all_100", "att_all_100"]
Wd = agg[HM].unstack("scenario")
homes = Wd.index.values
IDX = np.random.default_rng(2026).integers(0, len(homes), (5000, len(homes)))   # home-cluster bootstrap


def boot(v): return v[IDX].mean(axis=1)


EST = {}
for k in HM:
    for s in SC:
        v = Wd[(k, s)].values; b = boot(v); EST[(s, k)] = (v.mean(), np.percentile(b, 2.5), np.percentile(b, 97.5))
pd.Series({kk: f"{a:.3f} [{l:.3f}, {u:.3f}]" for kk, (a, l, u) in EST.items()}).unstack().loc[SC, HM].to_csv("results/main_fixed_home_bootstrap.csv")
PAIRS = [("S1", "S0"), ("S2", "S1"), ("S2", "S0"), ("S2-noVerify", "S2"), ("S2-noEscalate", "S2"), ("S2-noTier", "S2"), ("S2-noAdapt", "S2"),
         ("S0", "S0-fixedRule"), ("S1", "S1-fixedRule")]
DIF = {}
for a, b_ in PAIRS:
    for k in HM:
        d = Wd[(k, a)].values - Wd[(k, b_)].values; bb = boot(d); DIF[(a, b_, k)] = (d.mean(), np.percentile(bb, 2.5), np.percentile(bb, 97.5))
pd.Series({(f"{a} vs {b_}", k): f"{m:+.3f} [{l:+.3f}, {u:+.3f}]" for (a, b_, k), (m, l, u) in DIF.items()}).unstack().to_csv("results/main_fixed_paired_differences.csv")

LAB = {"S0-fixedRule": "S0 alert-only (fixed daytime rule)", "S1-fixedRule": "S1 designated responder (fixed daytime rule)", "S0": "S0 alert-only",
       "S1": "S1 designated responder", "S2": "S2 full framework", "S2-noVerify": "S2 without verification call", "S2-noEscalate": "S2 without escalation",
       "S2-noTier": "S2 without tiering / night routing", "S2-noAdapt": "S2 without history-based personal thresholds"}


def f(t, d=3): return f"{t[0]:.{d}f} ({t[1]:.{d}f}–{t[2]:.{d}f})"


T3 = []
for s in SC:
    util = SYS.loc[s, ("mean", "resp_util")]
    T3.append({"Scenario": LAB[s], "Background alerts /100 home-days": f(EST[(s, "n_alert_100")], 1),
               "Background-alert family notifications /100 home-days": f(EST[(s, "fam_100")], 2),
               "Background-alert night-time family notifications /100 home-days": f(EST[(s, "fam_night_100")], 2),
               "Background-alert family home visits /100 home-days": f(EST[(s, "fam_visit_100")], 2),
               "All responder dispatches /100 home-days": f(EST[(s, "disp_all_100")], 2),
               "In-year responder attendances /100 home-days": f(EST[(s, "att_all_100")], 2),
               "Responder demand load ratio": ("—" if util == 0 else (f"{util:.2f} (unstable)" if util >= 1 else
                                         f"{util:.2f} ({SYS.loc[s, ('lo', 'resp_util')]:.2f}–{SYS.loc[s, ('hi', 'resp_util')]:.2f})")),
               "Long lie ≥60 min, all falls": f(EST[(s, "ll60_r")]), "Long lie ≥60 min, device-signalled falls": f(EST[(s, "ll60dev_r")]),
               "Long lie ≥120 min, all falls": f(EST[(s, "ll120_r")]),
               "Median time to help, device-signalled falls (min)": f"{SYS.loc[s, ('mean', 'help_med_device')]:.0f} ({SYS.loc[s, ('lo', 'help_med_device')]:.0f}–{SYS.loc[s, ('hi', 'help_med_device')]:.0f})"})
pd.DataFrame(T3).to_csv("results/table_main_results.csv", index=False)
pd.DataFrame([{"Comparison": f"{LAB[a]} vs {LAB[b_]}", **{lab: f(DIF[(a, b_, k)], 3 if k.startswith("ll") else 2) for k, lab in
               [("ll60_r", "Δ long lie, all falls"), ("ll60dev_r", "Δ long lie, device-signalled"), ("fam_100", "Δ background-alert family notifications /100 hd"),
                ("fam_night_100", "Δ background-alert night family notifications /100 hd"), ("disp_all_100", "Δ all responder dispatches /100 hd")]}} for a, b_ in PAIRS]
             ).to_csv("results/table_paired_differences.csv", index=False)

# responder accounting: requests received, attended within the simulated year, still open at its end (system level)
ACC = ["resp_callout_per100", "resp_requests_all_per100", "resp_attended_inyear_per100", "resp_open_at_end", "resp_waiting_at_end",
       "resp_util", "resp_util_inyear", "resp_wait_mean", "resp_wait_p95", "falls_help_after_end", "falls_undetected", "n_benign_dropped"]
ga = mb.groupby("scenario")[ACC]
pd.concat({"mean": ga.mean(), "lo": ga.quantile(.025), "hi": ga.quantile(.975)}, axis=1).loc[SC].to_csv("results/responder_accounting.csv")

# Monte Carlo standard errors (fixed homes, 500 replications): per policy and for paired differences
MC = []
for k in ["long_lie60", "ll60_device", "long_lie120", "fam_notif_per100", "resp_callout_per100", "resp_util", "resp_wait_mean"]:
    w = mf.pivot(index="rep", columns="scenario", values=k)
    for s in SC:
        x = w[s].dropna(); MC.append(dict(metric=k, contrast=s, mean=x.mean(), sd=x.std(), n=len(x), se=x.std() / np.sqrt(len(x))))
    for a, b_ in PAIRS:
        d = (w[a] - w[b_]).dropna()
        MC.append(dict(metric=k, contrast=f"{a} - {b_}", mean=d.mean(), sd=d.std(), n=len(d), se=d.std() / np.sqrt(len(d)),
                       corr=np.corrcoef(w[a], w[b_])[0, 1] if w[a].std() > 0 and w[b_].std() > 0 else np.nan))
pd.DataFrame(MC).to_csv("results/mc_standard_errors.csv", index=False)

# variation between catchments: per-replication paired differences in the home-resampled experiment (1000 catchments).
# The spread combines differences in home composition and the random variation of a single simulated year.
BC = []
for a, b_ in [("S1", "S0"), ("S2", "S1"), ("S2", "S0")]:
    for k, sc_ in [("long_lie60", 100), ("ll60_device", 100), ("fam_notif_per100", 1), ("resp_requests_all_per100", 1)]:
        w = mb.pivot(index="rep", columns="scenario", values=k); d = ((w[a] - w[b_]) * sc_).dropna()
        BC.append(dict(comparison=f"{a} - {b_}", metric=k, unit="percentage points" if sc_ == 100 else "per 100 home-days", reps=len(d),
                       mean=d.mean(), p2_5=d.quantile(.025), p97_5=d.quantile(.975), share_below_zero=(d < 0).mean()))
pd.DataFrame(BC).to_csv("results/between_catchment_variation.csv", index=False)
TS4 = []   # Table S4 as printed in the Supplementary Materials
BCL = {"long_lie60": ("Long lie \u2265 60 min, all falls", 1), "ll60_device": ("Long lie \u2265 60 min, device-signalled falls", 1),
       "fam_notif_per100": ("Background-alert family notifications", 2), "resp_requests_all_per100": ("All responder dispatches", 2)}
for r in BC:
    if r["comparison"] == "S1 - S0" and r["metric"] in ("fam_notif_per100", "resp_requests_all_per100"):
        continue   # identical in S0 and S1 by design
    lab, dg = BCL[r["metric"]]
    fm = lambda x: f"{x:+.{dg}f}".replace("-", "\u2212") if abs(x) >= 0.5 * 10 ** -dg else f"{0:.{dg}f}"
    TS4.append({"Comparison": r["comparison"].replace(" - ", " \u2212 "), "Outcome": lab, "Unit": r["unit"], "Mean": fm(r["mean"]),
                "2.5th percentile": fm(r["p2_5"]), "97.5th percentile": fm(r["p97_5"]),
                "Catchments with a lower value (%)": f"{100 * r['share_below_zero']:.1f}"})
pd.DataFrame(TS4).to_csv("results/table_S4_between_catchment.csv", index=False)

# ---------------------------------------------------------------- policy sweeps (Figure 7)
COLS = ["long_lie60", "ll60_device", "fam_notif_per100", "fam_notif_night_per100", "resp_callout_per100", "resp_util", "resp_wait_mean", "resp_wait_p95", "help_med_device"]
for key, prefix, vals, name in [("c", "sw_c", [1, 2, 3, 4], "c"), ("s", "sw_s", [0.0, 0.25, 0.5, 0.75, 0.9], "s"),
                                ("L", "sw_L", [5, 10, 15, 30], "L_r"), ("pn", "sw_pn", [0.2, 0.35, 0.5, 0.65, 0.8], "p_night")]:
    rows = []
    for v in vals:
        x = load(f"{prefix}{v}"); g = x.groupby("scenario")[COLS]
        m_ = g.mean().join(g.sem().add_suffix("_se")); m_[name] = v; m_["reps"] = g.size()
        ref = "S1" if "S1" in m_.index else "S2"     # paired Monte Carlo SE of the difference to the reference policy
        for k in ["long_lie60", "ll60_device"]:
            w = x.pivot(index="rep", columns="scenario", values=k)
            for s in m_.index:
                d = (w[s] - w[ref]).dropna()
                m_.loc[s, f"{k}_diff_vs_ref"] = d.mean(); m_.loc[s, f"{k}_diff_se"] = d.std() / np.sqrt(len(d)) if len(d) > 1 else np.nan
        m_["ref"] = ref; rows.append(m_.reset_index())
    pd.concat(rows, ignore_index=True).to_csv(f"results/sweep_{key}.csv", index=False)

# ---------------------------------------------------------------- detection-parameter sensitivity
rows = []
for k, lab in [("det_b1.0", "buffer 1.0"), (None, "buffer 1.2 (main)"), ("det_b1.5", "buffer 1.5"), ("det_w30", "window 30 d"), ("det_w90", "window 90 d")]:
    root = f"data/derived_{k}" if k else "data/derived"
    bp = pd.read_parquet(f"{root}/benign_personal.parquet"); d = pd.read_parquet(f"{root}/fall_library_day.parquet").det_personal
    m_ = (load(f"sens_{k}") if k else mf[mf.scenario.isin(["S1", "S2", "S2-noAdapt"])]).groupby("scenario")[["long_lie60", "ll60_device", "fam_notif_per100", "resp_util", "resp_callout_per100"]].mean()
    rows.append(dict(setting=lab, alerts_per100=round(len(bp) / EVD * 100, 2), det_median=round(d.median()), det_le120=round((d <= 120).mean(), 3),
                     undet48=round(d.isna().mean(), 3), S2_ll60=round(m_.loc["S2", "long_lie60"], 3), S1_ll60=round(m_.loc["S1", "long_lie60"], 3),
                     S2_fam=round(m_.loc["S2", "fam_notif_per100"], 2), S2_util=round(m_.loc["S2", "resp_util"], 3), S2_callout=round(m_.loc["S2", "resp_callout_per100"], 2)))
pd.DataFrame(rows).to_csv("results/detection_sensitivity.csv", index=False)

# ---------------------------------------------------------------- global sensitivity analysis (Figure 8)
G = pd.concat([pd.read_parquet(f) for f in glob.glob("results/gsa/*.parquet")], ignore_index=True)
Dg = pd.read_csv("results/gsa_design.csv")
gm = G.groupby(["set", "scenario"])[["long_lie60", "ll60_device", "fam_notif_per100", "resp_util"]].mean().unstack("scenario")
Y = pd.DataFrame({"d_ll60": gm[("long_lie60", "S2")] - gm[("long_lie60", "S1")], "d_ll60_dev": gm[("ll60_device", "S2")] - gm[("ll60_device", "S1")],
                  "d_fam": gm[("fam_notif_per100", "S2")] - gm[("fam_notif_per100", "S1")], "S2_util": gm[("resp_util", "S2")],
                  "S2_ll60": gm[("long_lie60", "S2")], "S1_ll60": gm[("long_lie60", "S1")]})
import gsa as gsa_mod
PD = gsa_mod.paired_set_differences(G)
for y, col in [("long_lie60", "d_ll60"), ("ll60_device", "d_ll60_dev")]:   # direction with 95% Monte Carlo interval
    Y[f"{col}_se"] = PD[y]["se"]; Y[f"{col}_reps"] = PD[y]["n"]
    lo_, hi_ = Y[col] - 1.96 * Y[f"{col}_se"], Y[col] + 1.96 * Y[f"{col}_se"]
    Y[f"{col}_class"] = np.where(hi_ < 0, "S2 better", np.where(lo_ > 0, "S2 worse", "indeterminate"))
gs = Y.join(Dg.loc[Y.index]); gs.to_csv("results/gsa_set_level.csv")
pd.DataFrame({c: gs[f"{c}_class"].value_counts() for c in ["d_ll60", "d_ll60_dev"]}).fillna(0).astype(int).to_csv("results/gsa_direction_counts.csv")
PAR = Dg.columns.tolist(); R = gs[PAR + ["d_ll60", "d_ll60_dev", "d_fam", "S2_util"]].rank()


def prcc(y):   # partial rank correlation coefficients with t-test p-values
    out = {}
    for p in PAR:
        o = [q for q in PAR if q != p]; X = np.column_stack([np.ones(len(R)), R[o].values])
        rx = R[p].values - X @ np.linalg.lstsq(X, R[p].values, rcond=None)[0]; ry = R[y].values - X @ np.linalg.lstsq(X, R[y].values, rcond=None)[0]
        r = np.corrcoef(rx, ry)[0, 1]; dfree = len(R) - 2 - len(o); t = r * np.sqrt(dfree / (1 - r ** 2))
        out[p] = (r, 2 * stats.t.sf(abs(t), dfree))
    return out


rows = []
for y in ["d_ll60", "d_ll60_dev", "d_fam", "S2_util"]:
    for p, (r, pv) in prcc(y).items():
        rows.append(dict(outcome=y, parameter=p, prcc=r, p=pv, significant=pv < 0.001 / 13))
pd.DataFrame(rows).to_csv("results/gsa_prcc.csv", index=False)
print(f"GSA: S2 lower all-fall long lie in {(gs.d_ll60 < 0).sum()}/{len(gs)} sets; fewer family notifications in {(gs.d_fam < 0).sum()}/{len(gs)}")
print("GSA direction (95% MC interval):", gs.d_ll60_class.value_counts().to_dict(), "device:", gs.d_ll60_dev_class.value_counts().to_dict())

# ---------------------------------------------------------------- informal discovery (Table 4)
I = load("informal"); I["amb_n"] = I.n - I.n_dev
pooled = I.groupby(["informal", "scenario"]).agg(n=("n", "sum"), ll60=("ll60", "sum"), n_dev=("n_dev", "sum"), ll60_dev=("ll60_dev", "sum"), amb_n=("amb_n", "sum"), ll60_amb=("ll60_amb", "sum"))
pooled["LL_all"] = pooled.ll60 / pooled.n; pooled["LL_dev"] = pooled.ll60_dev / pooled.n_dev; pooled["LL_amb"] = pooled.ll60_amb / pooled.amb_n
pooled.to_csv("results/informal_pooled.csv")
I["r_all"] = I.ll60 / I.n; I["r_dev"] = I.ll60_dev / I.n_dev; D = []
for k in ["none", "p33", "p49"]:
    x = I[I.informal == k].pivot(index="rep", columns="scenario", values=["r_all", "r_dev"])
    for a, b in [("S1", "S0"), ("S2", "S1"), ("S2-noVerify", "S2"), ("S2-noEscalate", "S2"), ("S2-noTier", "S2"), ("S2-noAdapt", "S2")]:
        for m in ["r_all", "r_dev"]:
            d = (x[(m, a)] - x[(m, b)]).dropna(); se = d.std() / np.sqrt(len(d))
            D.append(dict(informal=k, comparison=f"{a} - {b}", metric=m, diff=d.mean(), lo=d.mean() - 1.96 * se, hi=d.mean() + 1.96 * se))
pd.DataFrame(D).to_csv("results/informal_paired_differences.csv", index=False)

# ---------------------------------------------------------------- initialisation bias (Section 2.8)
Wm = load("warmup")
M = ["long_lie60", "ll60_device", "help_med_device", "fam_notif_per100", "fam_notif_night_per100", "resp_callout_per100", "resp_util", "resp_wait_mean", "resp_wait_p95"]
rows = []
for s in ["S1", "S2", "S2-noTier", "S2-noAdapt", "S2-noVerify"]:
    x = Wm[Wm.scenario == s].pivot(index="rep", columns="warm", values=M)
    for k in M:
        base = x[(k, 0)]
        for w in [14, 30]:
            d = x[(k, w)] - base; se = d.std() / np.sqrt(d.notna().sum())
            rows.append(dict(scenario=s, metric=k, warm=w, mean_w0=base.mean(), mean_w=x[(k, w)].mean(), diff=d.mean(), lo=d.mean() - 1.96 * se,
                             hi=d.mean() + 1.96 * se, rel=(d.mean() / base.mean() * 100) if base.mean() != 0 else np.nan))
pd.DataFrame(rows).to_csv("results/warmup_paired_differences.csv", index=False)

# ---------------------------------------------------------------- supplementary experiments (Section 2.6, Table 5)
X = pd.concat([pd.read_csv(f) for f in sorted(glob.glob("results/extra/extra_*.csv"))], ignore_index=True)
O = X[X.exp == "offset"]; om = ["long_lie60", "ll60_device", "fam_notif_per100", "resp_util", "resp_wait_mean", "resp_wait_p95"]
piv = O.pivot_table(index=["scenario", "rep"], columns="mode", values=om); rows = []
for s in ["S0", "S1", "S2"]:
    for m in om:
        d = piv.loc[s][(m, "strat")] - piv.loc[s][(m, "base")]; se = d.std() / np.sqrt(len(d))
        rows.append(dict(scenario=s, metric=m, base=piv.loc[s][(m, "base")].mean(), stratified=piv.loc[s][(m, "strat")].mean(), diff=d.mean(), lo=d.mean() - 1.96 * se, hi=d.mean() + 1.96 * se))
pd.DataFrame(rows).to_csv("results/extra_offsets.csv", index=False)
Fo = X[X.exp == "fall_overlap"]; dup = X[X.exp == "dup"].dup_share
pd.DataFrame([dict(benign_alerts=int(Fo.n_benign.sum()), overlapping=int(Fo.n_overlap.sum()), share=Fo.n_overlap.sum() / Fo.n_benign.sum(),
                   removed_after_fall=int(Fo.n_dropped.sum()), removed_per_rep=Fo.n_dropped.mean(), reps=len(Fo),
                   falls=int(Fo.n_falls.sum()), falls_with_overlap=int(Fo.falls_with.sum()), duplicate_offset_share_mean=dup.mean(),
                   duplicate_offset_share_min=dup.min(), duplicate_offset_share_max=dup.max())]).to_csv("results/extra_fall_overlap.csv", index=False)

# ---------------------------------------------------------------- responder schedules by time of day (Table 5)
STAFF = [(1, 1), (2, 1), (1, 2), (2, 2), (1, 3), (2, 3)]
SM = ["long_lie60", "ll60_device", "resp_wait_day", "resp_wait_night", "resp_wait_p95", "resp_util", "resp_util_inyear", "overtime_min_per_day",
      "overtime_share", "open_0600_mean", "open_0600_days_share", "help_med_device"]


def staffing_table(prefix):
    base = load(f"{prefix}d2n2").set_index("rep"); rows = []
    for cd, cn in STAFF:
        x = load(f"{prefix}d{cd}n{cn}").set_index("rep"); d = x.ll60_device - base.ll60_device; da = x.long_lie60 - base.long_lie60
        rows.append(dict(c_day=cd, c_night=cn, responder_hours=16 * cd + 8 * cn, reps=len(x), **{k: x[k].mean() for k in SM},
                         ll60_device_se=x.ll60_device.sem(), diff_dev_vs_2_2=d.mean(), diff_dev_lo=d.mean() - 1.96 * d.sem(), diff_dev_hi=d.mean() + 1.96 * d.sem(),
                         diff_all_vs_2_2=da.mean(), diff_all_lo=da.mean() - 1.96 * da.sem(), diff_all_hi=da.mean() + 1.96 * da.sem()))
    return pd.DataFrame(rows)


staffing_table("staff_").to_csv("results/table_staffing.csv", index=False)
rows = []   # paired comparisons of schedules (same seeds): 40 vs 40 scheduled responder-hours, and against the base schedule
for (a1, a2), (b1, b2) in [((1, 3), (2, 1)), ((1, 3), (2, 2)), ((1, 2), (2, 2)), ((2, 1), (2, 2))]:
    x = load(f"staff_d{a1}n{a2}").set_index("rep"); y = load(f"staff_d{b1}n{b2}").set_index("rep"); r = dict(schedule=f"{a1}/{a2}", reference=f"{b1}/{b2}")
    for k in ["ll60_device", "long_lie60"]:
        d = (x[k] - y[k]) * 100; r.update({f"{k}_diff_pp": d.mean(), f"{k}_lo": d.mean() - 1.96 * d.sem(), f"{k}_hi": d.mean() + 1.96 * d.sem()})
    r.update(hours=16 * a1 + 8 * a2, hours_ref=16 * b1 + 8 * b2, overtime=x.overtime_min_per_day.mean(), overtime_ref=y.overtime_min_per_day.mean(), reps=len(x))
    rows.append(r)
pd.DataFrame(rows).to_csv("results/staffing_paired_comparisons.csv", index=False)

# ---------------------------------------------------------------- decomposition of the model revision (V0 -> V1 -> V2, paired by seed)
DM = ["long_lie60", "ll60_device", "long_lie120", "help_med_device", "fam_notif_per100", "fam_notif_night_per100", "fam_visit_per100",
      "resp_callout_per100", "resp_requests_all_per100", "resp_attended_inyear_per100", "resp_util", "resp_util_inyear", "resp_wait_mean", "init15"]
VV = {"V0": load("dec_V0"), "V1": load("dec_V1"), "V2": mf[mf.scenario.isin(["S0", "S1", "S2", "S2-noVerify"])]}
rows = []
for s in ["S0", "S1", "S2", "S2-noVerify"]:
    for k in DM:
        w = pd.DataFrame({v: x[x.scenario == s].set_index("rep")[k] for v, x in VV.items()})
        r = dict(scenario=s, metric=k, **{v: w[v].mean() for v in VV})
        for a, b_ in [("V1", "V0"), ("V2", "V1"), ("V2", "V0")]:
            d = (w[a] - w[b_]).dropna(); r[f"{a}-{b_}"] = d.mean(); r[f"{a}-{b_}_lo"] = d.mean() - 1.96 * d.sem(); r[f"{a}-{b_}_hi"] = d.mean() + 1.96 * d.sem()
        rows.append(r)
pd.DataFrame(rows).to_csv("results/decomposition_main.csv", index=False)
ST = {v: staffing_table(p) for v, p in [("V0", "decstaff_V0_"), ("V1", "decstaff_V1_"), ("V2", "staff_")]}
pd.concat(ST, names=["variant"]).reset_index(level=0).to_csv("results/decomposition_staffing.csv", index=False)


# ---------------------------------------------------------------- Tables S2-S4 as printed in the Supplementary Materials


def sgn(x, dg):   # signed value with a typographic minus; a rounded zero is printed without sign
    s = f"{x:+.{dg}f}".replace("-", "\u2212")
    return s[1:] if re.fullmatch("[+\u2212]0\\.0+", s) else s


dmt = pd.DataFrame(rows)
TS2_MET = [("long_lie60", "Long lie \u2265 60 min, all falls", 3), ("ll60_device", "Long lie \u2265 60 min, device-signalled", 3),
           ("long_lie120", "Long lie \u2265 120 min, all falls", 3), ("help_med_device", "Median time to help, device-signalled (min)", 1),
           ("fam_notif_per100", "Background-alert family notifications /100 home-days", 2),
           ("resp_requests_all_per100", "All responder dispatches /100 home-days", 2), ("resp_wait_mean", "Mean responder wait (min)", 1)]
TS2 = []
for s in ["S0", "S1", "S2", "S2-noVerify"]:
    for k, lab, dg in TS2_MET:
        if (s in ("S0", "S1") and k in ("resp_requests_all_per100", "resp_wait_mean")) or (s == "S2-noVerify" and k == "resp_wait_mean"):
            continue   # no responder in S0/S1; waiting time is non-stationary without C1
        r = dmt[(dmt.scenario == s) & (dmt.metric == k)].iloc[0]
        TS2.append({"Policy": "S2 without C1" if s == "S2-noVerify" else s, "Outcome": lab,
                    "V0": f"{r.V0:.{dg}f}", "V1": f"{r.V1:.{dg}f}", "V2 (final)": f"{r.V2:.{dg}f}",
                    "V1 \u2212 V0 (95% CI)": f"{sgn(r['V1-V0'], dg)} ({sgn(r['V1-V0_lo'], dg)}, {sgn(r['V1-V0_hi'], dg)})",
                    "V2 \u2212 V1 (95% CI)": f"{sgn(r['V2-V1'], dg)} ({sgn(r['V2-V1_lo'], dg)}, {sgn(r['V2-V1_hi'], dg)})"})
pd.DataFrame(TS2).to_csv("results/table_S2_model_checks.csv", index=False)
TS3 = []
for cd, cn in STAFF:
    r = {"Responders (day/night)": f"{cd}/{cn}"}
    for v in ["V0", "V1", "V2"]:
        x = ST[v].set_index(["c_day", "c_night"]).loc[(cd, cn)]; lab = "V2 (final)" if v == "V2" else v
        r[f"Long lie, {lab}"] = f"{x.ll60_device:.3f}"
        r[f"Change vs. 2/2, {lab}"] = "\u2014" if (cd, cn) == (2, 2) else sgn(x.diff_dev_vs_2_2, 3)
    TS3.append(r)
C3 = ["Responders (day/night)"] + [f"Long lie, {v}" for v in ["V0", "V1", "V2 (final)"]] + [f"Change vs. 2/2, {v}" for v in ["V0", "V1", "V2 (final)"]]
pd.DataFrame(TS3)[C3].to_csv("results/table_S3_schedule_checks.csv", index=False)

# ---------------------------------------------------------------- home inclusion (Section 2.2)
if os.path.exists("data/home_index.csv"):
    idx = pd.read_csv("data/home_index.csv"); vs = pd.read_csv("data/home_inclusion.csv", index_col=0); tab = []
    for _, r in idx.iterrows():
        h = r.home; row = dict(home=h, raw_events=int(r.n_events), first=str(r.start)[:10], last=str(r.end)[:10])
        row["status"] = "included" if h in HOMES else "excluded"
        if h in vs.index:
            row.update(calendar_days=int(vs.loc[h, "days"]), valid_days=int(vs.loc[h, "valid"]))
        if h in HOMES:
            dd = pd.read_parquet(f"data/episodes/{h}_days.parquet")
            row.update(eval_days=EVAL[h], door_ok_share=round(dd.loc[dd.valid, "door_ok"].mean(), 2))
        js = f"data/sensor_map/{h}.json"
        if os.path.exists(js):
            jj = json.load(open(js)); row["event_match_rate"] = round(jj["n_unique_keys"] / jj["n_raw"], 4)
        tab.append(row)
    pd.DataFrame(tab).to_csv("results/table_home_inclusion.csv", index=False)

# ---------------------------------------------------------------- data for Figures 3 and 5
_, _, BEN, FL, DL = ds.load_inputs("data/derived")
rows = []
for c, A in BEN.items():
    gg = A.assign(hour=(A.min_of_day // 60).astype(int)).groupby(["type", "hour"]).size().unstack(fill_value=0).reindex(columns=range(24), fill_value=0)
    for t in gg.index:
        rows.append(dict(config=c, type=t, **{f"h{k:02d}": 100 * gg.loc[t, k] / EVD for k in range(24)}))
pd.DataFrame(rows).to_csv("results/fig3a_alerts_by_hour.csv", index=False)
P = dict(ds.BASE); P["_return_raw"] = True; rq = []
for rep in range(100):
    cat = ds.Catchment({c: BEN[c] for c in ["generic", "personal"]}, FL, {h: int(v) for h, v in EVAL.items()}, HOMES, P, np.random.default_rng([20261116, rep]), DL)
    for s in ["S2", "S2-noAdapt"]:
        R_ = ds.run_scenario(cat, P, s)[0]["_raw"]
        rq.append(pd.DataFrame({"rep": rep, "scenario": s, "hour": ((R_["req"] % 1440) // 60).astype(int), "wait": R_["wait"]}))
RQ = pd.concat(rq, ignore_index=True)
H2 = RQ.groupby(["scenario", "hour"]).agg(n=("wait", "size"), wait_mean=("wait", "mean"), wait_p95=("wait", lambda x: np.percentile(x, 95))).reset_index()
H2["requests_per100hd"] = H2.n / (100 * 600 * 365) * 100
H2.to_csv("results/fig3b_dispatch_by_hour.csv", index=False)


def timelines_for_rep(rep):   # response timelines of device-signalled falls under S0, S1, and S2
    cat = ds.Catchment({c: BEN[c] for c in ["generic", "personal"]}, FL, {h: int(v) for h, v in EVAL.items()}, HOMES, P, np.random.default_rng([20261116, rep]), DL)
    RAW = {s: ds.run_scenario(cat, P, s)[0]["_raw"] for s in ["S0", "S1", "S2"]}
    tf_all = cat.falls.t_f.values; dev_all = RAW["S2"]["dev"]; up = cat.fall_draws["u_p"]; out = []
    for i in np.nonzero(dev_all)[0]:
        rec = dict(rep=rep, i=int(i), clock=np.mod(tf_all[i], 1440) / 60, home=cat.falls.home.values[i], u_p=up[i])
        for s, R_ in RAW.items():
            pos = np.searchsorted(np.nonzero(R_["detected"])[0], i); j = R_["nb"] + pos; o = R_["out"]
            rec.update({f"{s}_{k}": v for k, v in dict(detect=R_["t0"][j] - tf_all[i], first=o["first_action"][j] - tf_all[i], fam=o["fam_arrive"][j] - tf_all[i],
                        req=o["req"][j] - tf_all[i], resp=R_["resp_arrive"][j] - tf_all[i], help=np.fmin(o["fam_arrive"][j], R_["resp_arrive"][j]) - tf_all[i],
                        notified=bool(o["fam_notified"][j])).items()})
        out.append(rec)
    return pd.DataFrame(out)


C = pd.concat([timelines_for_rep(r) for r in range(10)], ignore_index=True)
groups = {"Day, family reachable": C[(C.clock.between(9, 17)) & (C.u_p < P["p_day"])],
          "Day, family unreachable": C[(C.clock.between(9, 17)) & (C.u_p >= P["p_day"])],
          "Night, family unreachable": C[((C.clock >= 22) | (C.clock < 6)) & (C.u_p >= P["p_night"])]}
cols = ["rep", "i", "clock", "home"] + [f"{s}_{k}" for s in ["S0", "S1", "S2"] for k in ["detect", "first", "fam", "req", "resp", "help", "notified"]]
sel, meds = {}, {}
for gname, c in groups.items():   # the case closest to the group medians of all three policies
    m = {s: c[f"{s}_help"].median() for s in ["S0", "S1", "S2"]}; meds[gname] = m
    sel[gname] = c.loc[sum(np.abs(c[f"{s}_help"] - m[s]) / m[s] for s in ["S0", "S1", "S2"]).idxmin()]
EX = pd.DataFrame({gname: r[cols] for gname, r in sel.items()}).T; EX["group_n"] = [len(groups[gname]) for gname in EX.index]
for s in ["S0", "S1", "S2"]:
    EX[f"{s}_group_median_help"] = [meds[gname][s] for gname in EX.index]
EX.to_csv("results/fig5_timeline_examples.csv")
print("tables written to results/")
