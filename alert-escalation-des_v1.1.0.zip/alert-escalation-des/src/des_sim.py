"""Trace-driven discrete-event simulation of alert-response policies.

A catchment of N_v virtual homes is built by resampling the evaluation-period alert streams of
the included CASAS homes (each real home is replicated k times with a random start offset; one
simulated year).  Falls that leave the resident unable to get up are injected on uniformly drawn virtual days;
each fall is taken from the historical day that the virtual home replays on that day (activity-
weighted time within the day; detection delay pre-computed from the real trace).

Every alert passes through the scenario's response logic.  Requests for the community
responder enter a non-preemptive priority queue with c servers (urgent before routine, FIFO
within class); a server is busy for travel + on-site time.  Times are minutes.
"""
import heapq, json, os
import numpy as np, pandas as pd

DAY = 1440.0
BASE = dict(
    s=0.5,            # P(fall is signalled immediately by a wearable / pendant device)
    lam=0.2,          # falls with inability to get up, per resident-year
    q_b=0.8,          # P(resident answers the verification call | benign alert)
    q_f=0.1,          # P(resident answers | fallen)
    p_day=0.8, p_night=0.5,   # P(designated family member reachable)
    A=3.0,            # mean acknowledgement delay of a reachable family member (exp)
    F=30.0, F_sd=15.0,        # family travel time (lognormal mean, sd)
    W_day=60.0, W_night=30.0, # passive-message noticing delay: day exp(mean); night: next 07:00 + exp(mean)
    C=45.0, C_sd=10.0,        # community responder travel (normal, truncated 15-120)
    S_b=20.0, S_f=60.0,       # on-site time, benign / fall
    c=2,              # community responders on duty (24/7)
    L_u=5.0, L_r=15.0,        # acknowledgement time limits, urgent / routine
    call_delay=2.0,   # automated verification call
    nv_per_home=25, horizon_days=365,
    align_falls=True,       # draw each fall from the historical day that the virtual home replays on that day
    drop_after_fall_h=24.0, # remove the fallen resident's benign alerts from the fall to 24 h later
    unified_timing=True,    # device alerts skip the 2-min check call in every policy; day/night by notification time
    c_day=None, c_night=None,  # optional responder schedule (06:00-22:00 / 22:00-06:00); default: c around the clock
)
SCENARIOS = {
    # name: (detection config, verification, designated+ack, escalation, tiering/night routing, passive only)
    "S0": dict(det="generic", verify=False, active=False, escalate=False, tier=False),
    "S1": dict(det="generic", verify=False, active=True, escalate=False, tier=False),
    "S2": dict(det="personal", verify=True, active=True, escalate=True, tier=True),
    "S2-noVerify": dict(det="personal", verify=False, active=True, escalate=True, tier=True),
    "S2-noEscalate": dict(det="personal", verify=True, active=True, escalate=False, tier=True),
    "S2-noTier": dict(det="personal", verify=True, active=True, escalate=True, tier=False),
    "S2-noAdapt": dict(det="generic", verify=True, active=True, escalate=True, tier=True),
    "S0-fixedRule": dict(det="fixed", verify=False, active=False, escalate=False, tier=False),
    "S1-fixedRule": dict(det="fixed", verify=False, active=True, escalate=False, tier=False),
}
URGENT_TYPES = {"FALL_DEV", "E1", "E3"}


def load_inputs(root="data/derived", cfgs=("fixed", "generic", "personal")):
    """Included homes, evaluation days per home, benign alert streams, fall libraries (day library if present)."""
    meta = json.load(open(f"{root}/meta.json"))
    ben = {c: pd.read_parquet(f"{root}/benign_{c}.parquet") for c in sorted(set(cfgs))}
    fl = pd.read_parquet(f"{root}/fall_library.parquet")
    p = f"{root}/fall_library_day.parquet"
    dl = pd.read_parquet(p) if os.path.exists(p) else None
    return meta["homes"], {h: int(v) for h, v in meta["eval_len"].items()}, ben, fl, dl


def is_night(tmin):
    m = np.mod(tmin, DAY)
    return (m >= 22 * 60) | (m < 6 * 60)


def next_7am(tmin):
    d = np.floor(tmin / DAY) * DAY
    t7 = d + 7 * 60
    return np.where(tmin < t7, t7, t7 + DAY)


def lognorm(rng, mean, sd, n):
    s2 = np.log(1 + (sd / mean) ** 2)
    return rng.lognormal(np.log(mean) - s2 / 2, np.sqrt(s2), n)


def tnorm(rng, mean, sd, lo, hi, n):
    x = rng.normal(mean, sd, n)
    bad = (x < lo) | (x > hi)
    while bad.any():
        x[bad] = rng.normal(mean, sd, bad.sum()); bad = (x < lo) | (x > hi)
    return x


class Catchment:
    """Alert streams (benign + falls) for one replication, shared by all scenarios."""
    def __init__(self, ben, fl, eval_len, homes, P, rng, day_lib=None):
        H = P["horizon_days"]; k = P["nv_per_home"]
        self.n_homes = len(homes) * k; self.home_days = self.n_homes * H
        self.benign = {}
        offsets = [rng.integers(0, eval_len[h], k) for h in homes]   # one entry per slot (homes may repeat)
        for cfg in sorted(ben):                                      # fixed order -> reproducible seeds
            A = ben[cfg]; parts = []
            for slot, h in enumerate(homes):
                a = A[A.home == h]; e = a.vday.values - 60; ne = eval_len[h]
                for v, off in enumerate(offsets[slot]):
                    # virtual day i corresponds to evaluation day (off + i) mod ne
                    base_i = np.mod(e - off, ne)
                    reps = int(np.ceil(H / ne)) + 1
                    ii = (base_i[:, None] + ne * np.arange(reps)[None, :])
                    msk = ii < H
                    if not msk.any():
                        continue
                    rows = np.nonzero(msk)[0]
                    t = ii[msk] * DAY + a.min_of_day.values[rows]
                    parts.append(pd.DataFrame({"t": t, "type": a.type.values[rows], "vh": f"{slot}_{v}", "home": h}))
            self.benign[cfg] = pd.concat(parts, ignore_index=True).sort_values("t", ignore_index=True)
        # falls
        nf = rng.poisson(P["lam"] * H / 365.0, self.n_homes)
        vh_home = np.repeat(homes, k)
        rows = []
        aligned = P.get("align_falls", True) and day_lib is not None
        if aligned:
            groups = day_lib.groupby(["home", "e"]).indices
        for idx in np.nonzero(nf)[0]:
            h = vh_home[idx]
            if aligned:   # historical day replayed on the fall day, then a candidate fall from that day's trace
                day = rng.integers(0, H, nf[idx])
                ev = np.mod(offsets[idx // k][idx % k] + day, eval_len[h])
                pick_i = [groups[(h, int(e))][rng.integers(0, len(groups[(h, int(e))]))] for e in ev]
                pick = day_lib.iloc[pick_i]
            else:         # original design: candidate fall from any evaluation day of the home
                lib = fl[fl.home == h]
                pick = lib.iloc[rng.integers(0, len(lib), nf[idx])]
                day = rng.integers(0, H, nf[idx])
            rows.append(pick.assign(t_f=day * DAY + pick.min_of_day.values, vh=f"{idx // k}_{idx % k}"))
        src = day_lib if aligned else fl
        self.falls = pd.concat(rows, ignore_index=True) if rows else src.iloc[:0].assign(t_f=[], vh=[])
        # the fallen resident produces no ordinary activity: drop his/her benign alerts after the fall
        self.n_benign_dropped = 0
        win = P.get("drop_after_fall_h", 0.0) * 60.0
        if win > 0 and len(self.falls):
            Fw = self.falls[["vh", "t_f"]]
            for cfg in sorted(self.benign):
                B = self.benign[cfg]; sub = B[B.vh.isin(Fw.vh.values)].reset_index()
                if len(sub):
                    m = sub.merge(Fw, on="vh")
                    drop = m.loc[(m.t >= m.t_f) & (m.t < m.t_f + win), "index"].unique()
                    if len(drop):
                        self.benign[cfg] = B.drop(index=drop).reset_index(drop=True)
                        if cfg == "personal":
                            self.n_benign_dropped = len(drop)
        nfl = len(self.falls)
        self.u_dev = rng.random(nfl)   # CRN: device detection
        self.fall_draws = self._draws(rng, nfl, P)
        self.ben_draws = {cfg: self._draws(np.random.default_rng(rng.integers(2**63)), len(self.benign[cfg]), P) for cfg in sorted(self.benign)}

    @staticmethod
    def _draws(rng, n, P):
        return dict(u_q=rng.random(n), u_p=rng.random(n), A=rng.exponential(1.0, n), F=rng.random(n),
                    Wd=rng.exponential(1.0, n), Wn=rng.exponential(1.0, n), C=rng.random(n), u_late=rng.random(n))


def priority_queue_sim(t_req, prio, service, c):
    """Non-preemptive priority queue with c identical servers.
    prio 0 = urgent, 1 = routine; FIFO within class. Returns service start times."""
    n = len(t_req); start = np.empty(n)
    order = np.argsort(t_req, kind="stable")
    free = [0.0] * int(c); heapq.heapify(free)
    waiting = []; i = 0
    while i < n or waiting:
        if not waiting:
            j = order[i]; i += 1; heapq.heappush(waiting, (prio[j], t_req[j], j))
        tf = free[0]
        T = max(tf, min(w[1] for w in waiting))
        while i < n and t_req[order[i]] <= T:
            j = order[i]; i += 1; heapq.heappush(waiting, (prio[j], t_req[j], j))
        p, tr, j = heapq.heappop(waiting)
        heapq.heappop(free); start[j] = T
        heapq.heappush(free, T + service[j])
    return start


def priority_queue_shift(t_req, prio, service, c_day, c_night):
    """Priority queue with a day (06:00-22:00) and a night (22:00-06:00) staffing level.
    Server s is on duty when s < c_day (day) or s < c_night (night); a server starts a service only while on
    duty but finishes a service that runs past the end of the shift. Returns start times and servers."""
    n = len(t_req); start = np.empty(n); srv = np.empty(n, int)
    order = np.argsort(t_req, kind="stable"); cmax = max(c_day, c_night); free = np.zeros(cmax)

    def on_duty_from(sv, t):
        m = t % DAY; night = (m >= 1320) | (m < 360)
        if sv < (c_night if night else c_day):
            return t
        if night:
            return t + ((360 - m) if m < 360 else (DAY - m + 360))
        return t + (1320 - m)
    waiting = []; i = 0
    while i < n or waiting:
        if not waiting:
            j = order[i]; i += 1; heapq.heappush(waiting, (prio[j], t_req[j], j))
        tmin = min(w[1] for w in waiting)
        T, sv = min((on_duty_from(q, max(free[q], tmin)), q) for q in range(cmax))
        while i < n and t_req[order[i]] <= T:
            j = order[i]; i += 1; heapq.heappush(waiting, (prio[j], t_req[j], j))
        p, tr, j = heapq.heappop(waiting); start[j] = T; srv[j] = sv; free[sv] = T + service[j]
    return start, srv


def respond(t0, typ, is_fall, D, P, sc):
    """Vectorised response logic up to (a) closure, (b) family arrival, or (c) responder request.
    With P['unified_timing'], device-signalled alerts skip the 2-min check call in every policy, and in S2 the
    day/night decision is made at the time the family would be notified (after the verification call)."""
    n = len(t0); unified = P.get("unified_timing", True)
    dev = typ == "FALL_DEV"
    q = np.where(is_fall, P["q_f"], P["q_b"])
    answered = D["u_q"] < q
    A = D["A"] * P["A"]
    s2 = np.log(1 + (P["F_sd"] / P["F"]) ** 2)
    from scipy.stats import norm
    Fz = norm.ppf(np.clip(D["F"], 1e-9, 1 - 1e-9))
    F = np.exp(np.log(P["F"]) - s2 / 2 + np.sqrt(s2) * Fz)

    def wpass(t):   # delay until a non-acknowledged message is noticed
        return np.where(is_night(t), next_7am(t) + D["Wn"] * P["W_night"] - t, D["Wd"] * P["W_day"])
    urgent = np.isin(typ, list(URGENT_TYPES))
    out = dict(close=np.full(n, np.nan), fam_arrive=np.full(n, np.nan), req=np.full(n, np.nan),
               prio=np.where(urgent & sc["tier"], 0, 1), fam_notified=np.zeros(n, bool),
               fam_visit=np.zeros(n, bool), first_action=np.full(n, np.nan), t_notify=np.full(n, np.nan))
    chk = np.where(dev, 0.0, P["call_delay"]) if unified else np.full(n, P["call_delay"])
    if not sc["active"] or (not sc["escalate"] and not sc["verify"]):   # S0 (passive) or S1 (designated, ack)
        if sc["active"]:
            reach = D["u_p"] < np.where(is_night(t0), P["p_night"], P["p_day"])
            tn = t0 + np.where(reach, A, wpass(t0))
        else:
            tn = t0 + wpass(t0)
        out["fam_notified"][:] = True; out["t_notify"][:] = t0; out["first_action"] = tn
        ok = answered & ~is_fall
        out["close"][ok] = tn[ok] + P["call_delay"]
        go = ~ok
        out["fam_arrive"][go] = tn[go] + chk[go] + F[go]
        out["fam_visit"][go] = True
        return out
    # ---- S2 family of scenarios
    if sc["verify"]:
        vc = ~dev
        closed = vc & answered & ~is_fall
        out["close"][closed] = t0[closed] + P["call_delay"]
        out["first_action"][closed] = t0[closed] + P["call_delay"]
        confirmed = vc & answered & is_fall          # fallen resident answers -> confirmed emergency
        tn = np.where(vc, t0 + P["call_delay"], t0)
        pending = ~closed
    else:
        confirmed = np.zeros(n, bool); tn = t0.copy(); pending = np.ones(n, bool)
    night = is_night(tn) if unified else is_night(t0)
    reach = D["u_p"] < np.where(night, P["p_night"], P["p_day"])
    L = np.where(sc["tier"] & urgent, P["L_u"], P["L_r"]) if sc["tier"] else np.full(n, P["L_r"])
    direct = pending & night & sc["tier"] & sc["escalate"]       # night routing straight to responder
    direct |= pending & confirmed & sc["escalate"]
    out["req"][direct] = tn[direct]
    out["first_action"][direct] = tn[direct]
    fam = pending & ~direct
    out["fam_notified"][fam] = True; out["t_notify"][fam] = tn[fam]
    ack_in_time = fam & reach & (A <= L)
    out["first_action"][ack_in_time] = tn[ack_in_time] + A[ack_in_time]
    out["fam_arrive"][ack_in_time] = tn[ack_in_time] + A[ack_in_time] + F[ack_in_time]
    out["fam_visit"][ack_in_time] = True
    late = fam & ~ack_in_time
    if sc["escalate"]:
        out["req"][late] = tn[late] + L[late]
        out["first_action"][late] = tn[late] + L[late]
    else:   # unacknowledged message is seen later, family attends
        tl = tn + np.where(reach, A, wpass(tn) if unified else wpass(t0))
        out["first_action"][late] = tl[late]
        out["fam_arrive"][late] = tl[late] + F[late]
        out["fam_visit"][late] = True
    return out


def run_scenario(cat, P, sc_name):
    sc = SCENARIOS[sc_name]; cfg = sc["det"]
    B = cat.benign[cfg]; DB = cat.ben_draws[cfg]
    Fa = cat.falls
    dev = cat.u_dev < P["s"]
    det = Fa[f"det_{cfg}"].values
    t_det = np.where(dev, Fa.t_f.values + 1.0, Fa.t_f.values + det)   # NaN = not detected within 48 h
    detected = ~np.isnan(t_det)
    ftype = np.where(dev, "FALL_DEV", np.where(Fa[f"rule_{cfg}"].values == "E1", "E1", "E2"))
    t0 = np.concatenate([B.t.values, t_det[detected]])
    typ = np.concatenate([B.type.values, ftype[detected]])
    isf = np.concatenate([np.zeros(len(B), bool), np.ones(detected.sum(), bool)])
    D = {k: np.concatenate([DB[k], cat.fall_draws[k][detected]]) for k in DB}
    o = respond(t0, typ, isf, D, P, sc)
    # responder queue
    rq = ~np.isnan(o["req"])
    C = tnorm_from_u(D["C"][rq], P["C"], P["C_sd"])
    serv = C + np.where(isf[rq], P["S_f"], P["S_b"])
    shift = P.get("c_day") is not None
    if not rq.any():
        start = np.array([]); srv = np.array([], int)
    elif shift:
        start, srv = priority_queue_shift(o["req"][rq], o["prio"][rq], serv, int(P["c_day"]), int(P["c_night"]))
    else:
        start = priority_queue_sim(o["req"][rq], o["prio"][rq], serv, int(P["c"])); srv = None
    resp_arrive = np.full(len(t0), np.nan); resp_arrive[rq] = start + C
    wait = start - o["req"][rq]
    arrive = np.fmin(o["fam_arrive"], resp_arrive)
    # metrics
    nb = len(B); hd = cat.home_days; HE = P["horizon_days"] * DAY
    fall_help = np.full(len(Fa), np.inf)
    fall_help[detected] = arrive[nb:] - Fa.t_f.values[detected]
    # night-time family notification: by notification time (unified timing) or by alert time (original)
    night_b = is_night(o["t_notify"][:nb]) if P.get("unified_timing", True) else is_night(t0[:nb])
    staff_min = (16 * P["c_day"] + 8 * P["c_night"]) * 60 * P["horizon_days"] if shift else P["c"] * HE
    busy_in = np.clip(np.minimum(start + serv, HE) - np.minimum(start, HE), 0, None).sum() if rq.any() else 0.0
    t_help_abs = np.full(len(Fa), np.inf); t_help_abs[detected] = arrive[nb:]
    res = dict(
        n_falls=len(Fa),
        long_lie60=float(np.mean(fall_help >= 60)) if len(Fa) else np.nan,
        long_lie120=float(np.mean(fall_help >= 120)) if len(Fa) else np.nan,
        help_median=float(np.median(fall_help)) if len(Fa) else np.nan,
        ll60_device=float(np.mean(fall_help[dev] >= 60)) if dev.any() else np.nan,
        ll60_ambient=float(np.mean(fall_help[~dev] >= 60)) if (~dev).any() else np.nan,
        help_med_device=float(np.median(fall_help[dev])) if dev.any() else np.nan,
        n_dev=int(dev.sum()), n_ll60=int((fall_help >= 60).sum()), n_ll60_dev=int((fall_help[dev] >= 60).sum()),
        alerts_per100=100 * nb / hd,
        fam_notif_per100=100 * o["fam_notified"][:nb].sum() / hd,
        fam_notif_night_per100=100 * (o["fam_notified"][:nb] & night_b).sum() / hd,
        fam_visit_per100=100 * o["fam_visit"][:nb].sum() / hd,
        resp_callout_per100=100 * rq[:nb].sum() / hd,                       # requests from benign alerts
        resp_requests_all_per100=100 * rq.sum() / hd,                        # all requests received (incl. falls)
        resp_attended_inyear_per100=100 * (resp_arrive[rq] <= HE).sum() / hd if rq.any() else 0.0,
        resp_open_at_end=int((resp_arrive[rq] > HE).sum()) if rq.any() else 0,   # not yet attended at day 365
        resp_waiting_at_end=int((start > HE).sum()) if rq.any() else 0,         # not yet started at day 365
        resp_util=float(serv.sum() / staff_min) if rq.any() else 0.0,           # offered load
        resp_util_inyear=float(busy_in / staff_min),                             # busy share within the year
        resp_wait_mean=float(wait.mean()) if rq.any() else 0.0,
        resp_wait_p95=float(np.percentile(wait, 95)) if rq.any() else 0.0,
        falls_help_after_end=int((np.isfinite(t_help_abs) & (t_help_abs > HE)).sum()),   # detected, help after day 365
        falls_undetected=int((~detected).sum()),
        init15=float(np.mean((o["first_action"][:nb] - t0[:nb]) <= 15)),
        n_benign_dropped=int(getattr(cat, "n_benign_dropped", 0)),
    )
    if rq.any():
        rr = o["req"][rq]; nightr = is_night(rr)
        res.update(resp_wait_day=float(wait[~nightr].mean()) if (~nightr).any() else 0.0,
                   resp_wait_night=float(wait[nightr].mean()) if nightr.any() else 0.0,
                   resp_night_share=float(nightr.mean()))
        if shift:   # overtime of shift-limited responders and requests still open at 06:00
            end = start + serv; m = np.mod(start, DAY); d0 = np.floor(start / DAY) * DAY
            day_only = (srv >= P["c_night"]) & (srv < P["c_day"]); night_only = (srv >= P["c_day"]) & (srv < P["c_night"])
            shift_end = np.where(day_only, d0 + 1320, np.where(m >= 1320, d0 + DAY + 360, d0 + 360))
            ot = np.where(day_only | night_only, np.clip(end - shift_end, 0, None), 0.0)
            t6 = np.arange(P["horizon_days"]) * DAY + 360
            open6 = ((rr[None, :] < t6[:, None]) & (start[None, :] > t6[:, None])).sum(1)
            res.update(overtime_min_per_day=float(ot.sum() / P["horizon_days"]), overtime_share=float((ot > 0).mean()),
                       open_0600_mean=float(open6.mean()), open_0600_days_share=float((open6 > 0).mean()))
    # per-home aggregates (base home). callout: dispatches for background (benign) alerts; disp_f: dispatches after
    # detected falls; att_b / att_f: dispatches attended by a responder within the simulated year
    hb = B.home.values; hf = Fa.home.values
    att = rq & (resp_arrive <= HE)
    disp_f = np.zeros(len(Fa), bool); att_f = np.zeros(len(Fa), bool)
    disp_f[detected] = rq[nb:]; att_f[detected] = att[nb:]
    ph = pd.DataFrame({"home": hb, "n_alert": 1, "fam": o["fam_notified"][:nb], "fam_night": o["fam_notified"][:nb] & night_b,
                       "fam_visit": o["fam_visit"][:nb], "callout": rq[:nb], "att_b": att[:nb]}).groupby("home").sum()
    pf = pd.DataFrame({"home": hf, "n_fall": 1, "ll60": fall_help >= 60, "ll120": fall_help >= 120, "dev": dev,
                       "ll60_dev": (fall_help >= 60) & dev, "disp_f": disp_f, "att_f": att_f}).groupby("home").sum()
    res["_per_home"] = ph.join(pf, how="outer").fillna(0)
    if P.get("_return_raw"):
        res["_raw"] = dict(t0=t0, nb=nb, rq=rq, req=o["req"][rq], wait=wait, serv=serv, start=start,
                           fam_notified=o["fam_notified"][:nb], fam_visit=o["fam_visit"][:nb], night_b=night_b,
                           t_f=Fa.t_f.values, fall_help=fall_help, dev=dev, n_homes=cat.n_homes,
                           typ=typ, isf=isf, out=o, resp_arrive=resp_arrive, detected=detected, t_det=t_det)
    return res, fall_help, dev


def tnorm_from_u(u, mean, sd, lo=15.0, hi=120.0):
    from scipy.stats import norm
    a, b = norm.cdf((lo - mean) / sd), norm.cdf((hi - mean) / sd)
    return mean + sd * norm.ppf(a + u * (b - a))
