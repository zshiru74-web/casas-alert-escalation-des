# Reproducibility check, version 1.2.0

Date: 2026-11-20.

## Procedure

1. The release archive `alert-escalation-des_v1.2.0` was unpacked into an empty directory.
2. The outputs of steps 1-2 (`data/homes/`, `data/home_index.csv`, `data/sensor_map/`, `data/sensor_map_final/`) were copied
   in from the working copy used for the paper. Steps 1-2 only download, convert, and map the CASAS releases
   (Zenodo 10.5281/zenodo.16343844 and 10.5281/zenodo.15708568).
3. Steps 3-7 were run in order from the repository root, in the activated conda environment:

| Step | Run time |
|---|---|
| 3 `03_activity_episodes.py` | 61 s |
| 4 `04_alerts_fall_library.py` | 11 s |
| 5 `05_run_experiments.py` (14 processes; 238 jobs, 0 failures; 68 GSA sets extended) | 54.3 min |
| 6 `06_analyse.py` | 41 s |
| 7 `07_figures.py` | 11 s |

Environment: Python 3.11.18, NumPy 2.4.6, pandas 2.3.3, SciPy 1.17.1, pyarrow 26.0.1, Matplotlib 3.11.2;
Windows 11 (build 26200), 16 logical processors, 31 GB RAM.

## Result

* `data/derived/`, `data/episodes/`, `data/activity/`, and `data/home_inclusion.csv`: identical to the working copy.
* `results/`: 453 files; all 452 files present in the working copy are byte-identical. The additional file,
  `table_home_inclusion.csv`, is written only when `data/home_index.csv` is present; it gives 24 included homes,
  147,029,281 raw events, 21,578 valid days, 20,138 evaluation home-days, and event match rates of 98.2-100%
  in the included homes.
* `figures/`: Figure1-8.png are byte-identical; the PDF files differ only in their creation date.
* Tables 3, 4, S4, and S5 and Figures 1-8 of the paper were produced from these files.

`checksums_v1.2.0.sha256` lists the SHA-256 checksums of all files in `results/` and of `figures/Figure*.png`.
Check them after running steps 1-7 with `sha256sum -c checksums_v1.2.0.sha256` (Linux/macOS) or
`Get-FileHash -Algorithm SHA256` (Windows). Checksums of the main tables:

| File | SHA-256 |
|---|---|
| `results/table3_printed.csv` | `6dda93bfb811b4873fd96a11e67c25647af0fc906e11e8a844b1e6d21e2ae446` |
| `results/table4_2x2_contrasts.csv` | `d039c8525a7bda8532fff7f754ffc20272486cea7c4165d5fe7e5b39ae815aff` |
| `results/table_S2_model_checks.csv` | `64d50022ab217e6f122fcd541d38c732c0b5d2c0ec8d119b67b9605661a172a8` |
| `results/table_S3_schedule_checks.csv` | `87b73a001f44c9685a72e278f4423ab8c9b99564321f3a1ac2dd2d203f01637e` |
| `results/table_S4_between_catchment.csv` | `e6ce2c64b57959ae9e61562763fd58acbc4c3d175fd2c481a0dff7a4c3ff51c6` |
| `results/table_S5_travel_responders.csv` | `0100e4afc0109cd715a501a3956253576f7501817d34d3d14693c6d06f97ea17` |
| `results/gsa_direction_counts.csv` | `0fd2baaaaaa778c7ec32169068b4a284f871840fb58f90bcb7dab3d6c2f7c8dd` |
| `results/table_home_inclusion.csv` | `5a1f2423a7643322406f826cf19a81ce62ad7de1a3483805f20555362fbe8dcb` |
