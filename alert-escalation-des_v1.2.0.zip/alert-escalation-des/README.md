# Responsibility-based alert escalation for older adults living alone

Code for the paper *"Responsibility-Based Alert Escalation for Older Adults Living Alone: A Trace-Driven
Discrete-Event Simulation Using Smart-Home Sensor Data"*.

The pipeline turns the ambient-sensor recordings of 24 single-resident CASAS homes into causal alert streams,
injects falls requiring assistance, and simulates three alert-response policies in a 600-home catchment with
capacity-limited community responders:

* **S0** – alert-only message to the family;
* **S1** – designated family responder with acknowledgement;
* **S2** – responsibility-based framework: verification call (C1), designated responder (C2), escalation to a
  community responder (C3), tiering and night-time routing (C4), and outcome-informed personal thresholds (C5).

## Data

The sensor data are not redistributed here. Download them from Zenodo:

| Release | DOI | Used in |
|---|---|---|
| CASAS raw release (39 homes, 147.0 million events, 2009–2021) | [10.5281/zenodo.16343844](https://doi.org/10.5281/zenodo.16343844) | step 1 |
| CASAS mapped release (sensor-to-room labels) | [10.5281/zenodo.15708568](https://doi.org/10.5281/zenodo.15708568) | step 2 (read remotely) |

Place the zip archives of the raw release in `data/raw/`. Step 2 reads the mapped `data.zip` member by member
with HTTP range requests and needs internet access.

## Requirements

Python 3.11. Install the packages with

```
pip install -r requirements.txt
```

The results in the paper were produced with Python 3.11.18, NumPy 2.4.6, pandas 2.3.3, SciPy 1.17.1,
pyarrow 26.0.1, and Matplotlib 3.11.2 on Windows 11 (16 logical processors, 31 GB RAM), in a conda environment.
Run the scripts in the activated environment: on Windows, starting the environment's `python.exe` without
activation can leave NumPy's BLAS libraries off the search path, and step 6 then stops in `numpy.corrcoef` with
exit code 0xC06D007F.

## Running the pipeline

Run the scripts from the repository root, in order:

| Step | Command | Output | Paper |
|---|---|---|---|
| 1 | `python scripts/01_convert_raw.py` | `data/homes/`, `data/home_index.csv`, `data/sensor_inventory.csv` | Section 2.2 |
| 2 | `python scripts/02_sensor_map.py` | `data/sensor_map/`, `data/sensor_map_final/` | Section 2.1 |
| 3 | `python scripts/03_activity_episodes.py` | `data/activity/`, `data/episodes/`, `data/daily_qc.parquet`, `data/home_inclusion.csv` | Section 2.2 |
| 4 | `python scripts/04_alerts_fall_library.py` | `data/derived/` (alert streams, fall libraries, incl. `fall_library_day.parquet` with eight candidate falls per evaluation day) | Sections 2.3–2.4 |
| 5 | `python scripts/05_run_experiments.py` | `results/<experiment>/` | Sections 2.6–2.8 |
| 6 | `python scripts/06_analyse.py` | summary tables in `results/` (incl. Tables 3 and 4 in `table3_printed.csv` and `table4_2x2_contrasts.csv`, responder accounting, Monte Carlo standard errors, GSA direction, and Tables S2–S5 in their printed layout: `table_S2_model_checks.csv`, `table_S3_schedule_checks.csv`, `table_S4_between_catchment.csv`, `table_S5_travel_responders.csv`; `table_home_inclusion.csv` if `data/home_index.csv` from step 1 is present) | Tables 3–6, S2–S5, Section 3 |
| 7 | `python scripts/07_figures.py` | `figures/Figure1–8.png/.pdf` | Figures 1–8 |

Approximate run times on a 16-core desktop: steps 1–2, 10–20 min (depending on the network); step 3, 1–2 min;
step 4, under 1 min; step 5, 30–55 min with 14 parallel processes; steps 6–7, under 1 min.

## Code structure

| File | Content |
|---|---|
| `src/pipeline_events.py` | presence inference, alert rules E1–E3, fixed/generic/personal thresholds, fall detection delay (Equations (1)–(5)) |
| `src/des_sim.py` | catchment construction (falls aligned with the replayed day), response logic of S0–S2 and ablations, priority queue of community responders with optional day/night schedules, overtime and 06:00 backlog (Equations (6)–(9), Algorithms A1–A2) |
| `src/convert_casas.py`, `src/fetch_map.py` | workers for steps 1 and 2 |
| `src/run_batch.py` | replications of the main experiment, home-resampled experiment, sweeps, responder schedules, decomposition variants, and detection sensitivity |
| `src/build_derived.py` | alert streams for alternative detection settings |
| `src/gsa.py` | Latin hypercube design, runs of the global sensitivity analysis, and selection of sets for additional replications |
| `src/warmup_check.py`, `src/informal_discovery.py` | initialisation-bias check and informal-discovery sensitivity analysis |
| `src/sim_extra.py` | stratified start offsets, residual benign alerts during fall episodes, duplicated start offsets |

## Reproducibility

All random numbers come from NumPy generators with fixed seeds. Replication *r* of the main experiment uses
`numpy.random.default_rng([20261116, r])`; the global sensitivity analysis uses `default_rng([99, set, r])` and a
Latin hypercube design from `scipy.stats.qmc` with seed 7. Common random numbers are used across scenarios. Detection configurations are processed in a fixed
(sorted) order, so that results do not depend on Python's hash randomisation.

Model options in `des_sim.BASE`: `align_falls` (draw each fall from the day that the virtual home replays),
`drop_after_fall_h` (remove the fallen resident's benign alerts for 24 h), and `unified_timing` (device alerts
skip the check call in every policy; day and night judged at the notification time). The final model uses all
three; step 5 also runs the variants V0 and V1 used for the paired check in Tables S2–S3.
The model is reported following the STRESS-DES guideline (Table S1 of the paper).

The released version 1.2.0 was rerun from a clean copy (steps 3–7, from the converted and mapped data of steps 1–2);
all 453 files in `results/` and the PNG files of Figures 1–8 were byte-identical to those used in the paper. The
procedure is described in `REPRODUCIBILITY.md`, and `checksums_v1.2.0.sha256` lists the SHA-256 checksums of these
files (check with `sha256sum -c checksums_v1.2.0.sha256` after running steps 1–7).

## Archive

Version 1.0.0 of this code is archived on Zenodo: https://doi.org/10.5281/zenodo.24338803
(concept DOI for all versions: https://doi.org/10.5281/zenodo.24338802).

Version 1.1.0 changes only outputs and figures, not the simulated results: per-home counts of all responder
dispatches (including those after detected falls) and of in-year attendances are written by `src/des_sim.py`;
step 6 adds the between-catchment variation of paired differences (`results/between_catchment_variation.csv`,
Table S4) and paired comparisons of responder schedules (`results/staffing_paired_comparisons.csv`), and writes Tables S2–S4
exactly as printed in the Supplementary Materials (`results/table_S2_model_checks.csv`, `table_S3_schedule_checks.csv`,
`table_S4_between_catchment.csv`); step 7 redraws
Figure 1 (history-based personal thresholds, no feedback loop) and uses the labels "background-alert family
notifications", "all responder dispatches", and "demand load ratio"; Figures 4b and 6d plot all responder dispatches
(`disp_all_100`, including dispatches after detected falls) instead of the background-alert call-outs (`callout_100`) of
version 1.0.0. Version 1.1.0 was not released separately; its changes are included in version 1.2.0.

Version 1.2.0 changes the model and therefore the results:

* `src/pipeline_events.py`: the E2 (inactivity) search after a fall now covers the full 48-h detection horizon
  (`e2_first_cross`, `horizon_min=48 * 60`); versions up to 1.1.0 stopped after 24 h. With personal thresholds, the share
  of candidate falls not detected within 48 h fell from 1.84% to 1.07% (generic profile 0.89% to 0.85%; fixed rule unchanged),
  and four benign alerts after inactivity spells longer than 24 h were added (3143 to 3147). All experiments were rerun.
* `src/des_sim.py`: new scenario `S1-personal` (S1 with the personal thresholds of S2) for the 2 x 2 comparison of threshold
  type and response policy (S1-G = `S1`, S1-P = `S1-personal`, S2-G = `S2-noAdapt`, S2-P = `S2`).
* Step 5: joint sensitivity analysis of the mean responder travel time C (30-90 min) and the number of responders c (1-4)
  (`tc_C*_c*`, 200 replications each); S1-personal is added to the main experiments, sweeps of s and p_night, detection
  sensitivity, GSA, informal discovery, and the warm-up check. GSA sets are extended when the difference from S1 or
  S1-personal is within 2 Monte Carlo SE of zero.
* Step 6 writes Tables 3 and 4 as printed (`table3_printed.csv`, `table4_2x2_contrasts.csv`), the travel-time grid
  (`travel_responders.csv`, `table_S5_travel_responders.csv`), and GSA results for both S2 - S1 and S2 - S1-personal.
* Step 7: Figure 2c spans the full 48 h; Figure 4 adds S1-P; Figure 7a,b show the travel-time x responder grid;
  Figure 8 shows the response effect at equal thresholds (S2-P - S1-P).

## Terminology

* **S1-G, S1-P, S2-G, S2-P** – response policy S1 or S2 with the generic (G) or personal (P) alert thresholds.
* **Background alerts** – the benign alerts produced by the replayed traces; family notifications, night-time
  notifications, and family visits in Table 3 count only these alerts.
* **All dispatches** – all requests sent to a community responder, including those after detected falls.
* **In-year attendances** – dispatches attended by a responder within the simulated year.
* **Demand load ratio** – requested service time divided by scheduled responder time (`resp_util`); the utilisation
  based on actual busy time within the year is `resp_util_inyear`.
* The alert rules are replayed on offline quality-controlled traces: day validity and door-sensor functionality
  (±3 days) are judged from the complete record of each home.

## Estimates and intervals

* Tables 3 and 4 (rates, long-lie proportions, and 2 x 2 contrasts), Figures 4 and 6: experiment `main_fixed` (500 replications with the 24 homes).
  Each home's outcome is pooled over the replications; the point estimate is the mean of the 24 home values, and the
  95% interval is the 2.5th–97.5th percentile range of 5000 home-cluster bootstrap resamples
  (`main_fixed_home_bootstrap.csv`, `main_fixed_paired_differences.csv`).
* Demand load ratio, utilisation, waiting times, and median time to help (Table 3, Section 3): experiment `main_boot`
  (1000 replications, homes resampled with replacement in each); mean and 2.5th–97.5th percentiles over replications
  (`main_boot_summary.csv`). Table S4 uses the per-replication paired differences of the same experiment.
* Figure 7a,b and Table S5: experiments `tc_C*_c*` (200 replications per combination); per-replication paired
  differences S2 - S1-personal with 95% Monte Carlo intervals.
* Table 5 and the schedule comparisons: 200 replications per schedule with common random numbers; 95% Monte Carlo
  intervals of paired differences by normal approximation (`table_staffing.csv`, `staffing_paired_comparisons.csv`).
* Responder queue at the end of the year (Section 3.3): `resp_open_at_end` counts dispatches not yet attended and
  `resp_waiting_at_end` those whose service had not started (per-replication metrics of `main_fixed`).

## Citation

If you use this code, please cite the paper (reference to be added after publication) and the CASAS datasets
listed above.

## License

MIT License (see `LICENSE`). The CASAS data are subject to the terms of their Zenodo records.
