"""Step 7. Figures 1-8 of the paper (PNG at 600 dpi and PDF in figures/). Requires the outputs of step 6."""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import glob, json, os, re
import numpy as np, pandas as pd
import matplotlib as mpl
mpl.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Patch
from matplotlib.lines import Line2D
from matplotlib import cm
import _common  # noqa: F401

mpl.rcParams.update({"font.family": "sans-serif", "font.sans-serif": ["Arial", "Liberation Sans", "DejaVu Sans"],
                     "font.size": 7, "axes.labelsize": 8, "axes.titlesize": 8, "xtick.labelsize": 7, "ytick.labelsize": 7,
                     "legend.fontsize": 7, "axes.linewidth": 0.8, "xtick.major.width": 0.8, "ytick.major.width": 0.8,
                     "axes.grid": False, "grid.color": "#d9d9d9", "grid.linewidth": 0.5, "axes.axisbelow": True,
                     "savefig.dpi": 600, "pdf.fonttype": 42, "lines.linewidth": 1.0})
os.makedirs("figures", exist_ok=True)
COL = dict(S0="#999999", S1="#E69F00", S2="#0072B2"); BL = COL["S2"]
CFG = ["fixed", "generic", "personal"]; CFG_LAB = {"fixed": "Fixed daytime rule", "generic": "Generic 24-h profile", "personal": "Personal thresholds"}
CFG_COL = {"fixed": "#999999", "generic": "#56B4E9", "personal": "#0072B2"}
ABL = {"S0": ("o", COL["S0"], True, "S0 alert-only"), "S1": ("s", COL["S1"], True, "S1-G designated responder"),
       "S1-personal": ("s", COL["S1"], False, "S1-P designated responder, personal thresholds"), "S2": ("D", COL["S2"], True, "S2-P full framework"),
       "S2-noVerify": ("^", "#009E73", False, "S2 without C1 (verification call)"), "S2-noEscalate": ("v", "#CC79A7", False, "S2 without C3 (escalation)"),
       "S2-noTier": ("h", "#000000", False, "S2 without C4 (tiering / night routing)"), "S2-noAdapt": ("p", "#D55E00", False, "S2-G, S2 without C5 (generic thresholds)")}


def sublabels(fig, axes, letters, pad_pt=4):
    fig.canvas.draw(); r = fig.canvas.get_renderer(); inv = fig.transFigure.inverted()
    for ax, l in zip(axes, letters):
        bb = ax.get_tightbbox(r); x = ax.get_position().x0 + ax.get_position().width / 2
        y = inv.transform((0, bb.y0))[1] - pad_pt / 72 / fig.get_figheight()
        fig.text(x, y, rf"($\mathbf{{{l}}}$)", ha="center", va="top", fontsize=8)


def save(fig, n):
    fig.savefig(f"figures/Figure{n}.png", dpi=600, bbox_inches="tight"); fig.savefig(f"figures/Figure{n}.pdf", bbox_inches="tight"); plt.close(fig)


def parse(s):
    v = re.findall(r"[-\d.]+", s); return float(v[0]), float(v[1]), float(v[2])


meta = json.load(open("data/derived/meta.json")); homes = meta["homes"]; eval_len = meta["eval_len"]; evd = sum(eval_len.values())
BEN = {c: pd.read_parquet(f"data/derived/benign_{c}.parquet") for c in CFG}
FL = pd.read_parquet("data/derived/fall_library_day.parquet")   # candidate falls used by the simulation


# ------------------------------------------------------------------ Figure 1: workflow and S2 logic
def boxp(ax, x, y, w, h, text, fc="white", ec="#333333", lw=0.8, fs=7):
    p = FancyBboxPatch((x - w / 2, y - h / 2), w, h, boxstyle="round,pad=0.008,rounding_size=0.015", fc=fc, ec=ec, lw=lw); ax.add_patch(p)
    ax.text(x, y, text, ha="center", va="center", fontsize=fs, linespacing=1.15); return p


def link(ax, pA, pB, a=None, b=None, text=None, tpos=None, ha="center", color="#333333", ls="-", fs=6.5):
    ca = a if a is not None else (pA.get_x() + pA.get_width() / 2, pA.get_y() + pA.get_height() / 2)
    cb = b if b is not None else (pB.get_x() + pB.get_width() / 2, pB.get_y() + pB.get_height() / 2)
    ax.annotate("", xy=cb, xytext=ca, arrowprops=dict(arrowstyle="-|>", lw=0.8, color=color, ls=ls, mutation_scale=7, patchA=pA, patchB=pB, shrinkA=1.5, shrinkB=1.5))
    if text:
        ax.text(*tpos, text, ha=ha, va="center", fontsize=fs, color=color)


steps = ["CASAS raw sensor traces\n(39 homes, 147.0 M events)", "Room mapping and offline QC\n(24 single-resident homes,\n20,138 evaluation home-days)",
         "Alert rules E1–E3 replayed\non the QC traces\n(fixed / generic / personal)", "Alert streams + injected falls\n(detection delay from traces)",
         "Discrete-event simulation\n(600-home catchment, 1 year,\nresponder queue)", "Outcomes: long lie, family\nnotifications, responder dispatches"]
ys = np.linspace(0.93, 0.07, len(steps))
fig = plt.figure(figsize=(6.3, 3.9))
axa = fig.add_axes([0.0, 0.08, 0.29, 0.92]); axb = fig.add_axes([0.31, 0.08, 0.69, 0.92])
axa.set_xlim(0, 1); axa.set_ylim(-0.03, 1.03); axb.set_xlim(0, 1.10); axb.set_ylim(0, 1.10)
for ax in (axa, axb): ax.axis("off")
PA = [boxp(axa, 0.5, y, 0.92, 0.112, t, fc="#f2f2f2" if i in (0, 5) else "white") for i, (y, t) in enumerate(zip(ys, steps))]
for i in range(len(PA) - 1): link(axa, PA[i], PA[i + 1])
pAl = boxp(axb, 0.10, 0.86, 0.18, 0.11, "Alert\n(device fall,\nE1, E2, E3)", fc="#f2f2f2")
pC1 = boxp(axb, 0.43, 0.86, 0.24, 0.10, "C1 Verification call\nto resident (2 min)")
pCl = boxp(axb, 0.78, 0.86, 0.18, 0.10, "Closed\n(benign)", fc="#f2f2f2")
pC4 = boxp(axb, 0.43, 0.62, 0.24, 0.10, "C4 Tiering\nurgent L = 5 min\nroutine L = 15 min")
pC2 = boxp(axb, 0.14, 0.37, 0.24, 0.13, "C2 Designated\nfamily responder\n(acknowledgement)")
pC3 = boxp(axb, 0.71, 0.37, 0.26, 0.15, "C3 Escalation to\ncommunity responder\n(c responders,\npriority queue)")
pFT = boxp(axb, 0.14, 0.11, 0.24, 0.10, "Family travels\n(ack within L)", fc="#f2f2f2")
pRT = boxp(axb, 0.71, 0.11, 0.26, 0.10, "Responder travels\nand attends", fc="#f2f2f2")
pHA = boxp(axb, 0.425, 0.11, 0.21, 0.10, "Help arrives\n(time to help)", fc="#e6eef5", ec=BL)
pC5 = boxp(axb, 0.975, 0.62, 0.205, 0.18, "C5 History-\nbased personal\nthresholds\n(past 60 valid days)", ec=BL, fs=6.5)
link(axb, pAl, pC1, text="E1–E3", tpos=(0.25, 0.895)); link(axb, pC1, pCl, text="answered", tpos=(0.625, 0.895))
link(axb, pC1, pC4, text="no answer", tpos=(0.44, 0.74), ha="left")
link(axb, pAl, pC4, a=(0.10, 0.86), b=(0.43, 0.62), text="device fall\n(no call)", tpos=(0.215, 0.685))
link(axb, pC4, pC2, a=(0.38, 0.62), b=(0.18, 0.37), text="day", tpos=(0.24, 0.53))
link(axb, pC4, pC3, a=(0.48, 0.62), b=(0.66, 0.37), text="night (direct)", tpos=(0.66, 0.53))
link(axb, pC2, pC3, text="no ack within L", tpos=(0.42, 0.40))
link(axb, pC2, pFT); link(axb, pC3, pRT); link(axb, pFT, pHA); link(axb, pRT, pHA)
top = pC5.get_y() + pC5.get_height()
axb.plot([0.975, 0.975, 0.10, 0.10], [top, 1.03, 1.03, 0.97], color=BL, lw=0.8, ls="--")
axb.annotate("", xy=(0.10, 0.86), xytext=(0.10, 0.97), arrowprops=dict(arrowstyle="-|>", lw=0.8, color=BL, ls="--", mutation_scale=7, patchB=pAl, shrinkA=0, shrinkB=1.5))
axb.text(0.54, 1.055, "alert thresholds computed in advance from the resident's past activity", ha="center", va="center", fontsize=6.5, color=BL)
sublabels(fig, [axa, axb], ["a", "b"]); save(fig, 1)

# ------------------------------------------------------------------ Figure 2: alert load and detection delay
TYPE_COL = {"E1": "#4d4d4d", "E2": "#969696", "E3": "#d9d9d9"}
rates = {c: {t: (BEN[c].type == t).sum() / evd * 100 for t in ["E1", "E2", "E3"]} for c in CFG}
fig, axs = plt.subplots(1, 3, figsize=(6.3, 2.35), gridspec_kw=dict(width_ratios=[1, 0.9, 1.25], wspace=0.42))
ax = axs[0]; bottom = np.zeros(3)
for t, lab in [("E1", "E1 night bathroom stay"), ("E2", "E2 inactivity"), ("E3", "E3 night exit")]:
    v = np.array([rates[c][t] for c in CFG]); ax.bar(range(3), v, bottom=bottom, color=TYPE_COL[t], edgecolor="black", linewidth=0.4, width=0.62, label=lab); bottom += v
for i, v in enumerate(bottom): ax.text(i, v + 0.7, f"{v:.1f}", ha="center", va="bottom", fontsize=7)
ax.set_xticks(range(3)); ax.set_xticklabels(["Fixed", "Generic", "Personal"]); ax.set_ylabel("Alerts per 100 home-days")
ax.set_ylim(0, 50); ax.set_yticks(range(0, 51, 10)); ax.yaxis.grid(True)
ax.legend(frameon=False, fontsize=6.5, loc="upper right", bbox_to_anchor=(1.0, 1.0), handlelength=1.0, borderaxespad=0.2, labelspacing=0.3)
ax = axs[1]
e2 = {c: (BEN[c][BEN[c].type == "E2"].groupby("home").size().reindex(homes).fillna(0) / pd.Series(eval_len).reindex(homes) * 100) for c in ["generic", "personal"]}
for h in homes: ax.plot([0, 1], [e2["generic"][h], e2["personal"][h]], color="#bdbdbd", lw=0.6, zorder=1)
for x, c in [(0, "generic"), (1, "personal")]:
    ax.scatter(np.full(len(homes), x), e2[c].values, s=12, color=CFG_COL[c], edgecolor="black", linewidth=0.3, zorder=2)
    ax.plot([x - 0.18, x + 0.18], [e2[c].median()] * 2, color="black", lw=1.2, zorder=3)
ax.set_xticks([0, 1]); ax.set_xticklabels(["Generic", "Personal"]); ax.set_xlim(-0.4, 1.4); ax.set_ylim(0, 80)
ax.set_ylabel("Inactivity alerts per 100 home-days"); ax.yaxis.grid(True)
ax = axs[2]
for c in CFG:
    x = np.sort(FL[f"det_{c}"].fillna(np.inf).values / 60); und = 100 * FL[f"det_{c}"].isna().mean()
    ax.step(x, np.arange(1, len(x) + 1) / len(x), where="post", color=CFG_COL[c], lw=1.2, label=f"{CFG_LAB[c]} ({und:.2f}%)")
ax.axvline(1, color="#D55E00", lw=0.8, ls="--"); ax.text(1.35, 0.97, "1 h", fontsize=6.5, color="#D55E00", va="top")
ax.set_xlim(0, 48); ax.set_xticks([0, 6, 12, 24, 36, 48]); ax.set_xlabel("Ambient detection delay (h)"); ax.set_ylabel("Cumulative proportion of falls"); ax.set_ylim(0, 1.0)
ax.grid(True); ax.legend(frameon=False, fontsize=6.3, loc="lower right", handlelength=1.4, title="Not detected within 48 h", title_fontsize=6.3)
sublabels(fig, list(axs), ["a", "b", "c"]); save(fig, 2)

# ------------------------------------------------------------------ Figure 3: time of day
a3 = pd.read_csv("results/fig3a_alerts_by_hour.csv"); b3 = pd.read_csv("results/fig3b_dispatch_by_hour.csv"); hc = [f"h{h:02d}" for h in range(24)]
fig, axs = plt.subplots(1, 3, figsize=(6.3, 2.45)); fig.subplots_adjust(left=0.08, right=0.99, bottom=0.30, top=0.97, wspace=0.42)
edges = np.arange(25)


def night(ax):
    ax.axvspan(0, 6, color="#ececec", zorder=0, lw=0); ax.axvspan(22, 24, color="#ececec", zorder=0, lw=0)
    ax.set_xlim(0, 24); ax.set_xticks([0, 6, 12, 18, 24]); ax.set_xlabel("Hour of day")


ax = axs[0]; night(ax)
for c in CFG: ax.stairs(a3[a3.config == c][hc].sum(0).values, edges, color=CFG_COL[c], lw=1.2, label=CFG_LAB[c], baseline=None)
ax.set_ylabel("Alerts per 100 home-days"); ax.set_ylim(0, 8)
ax.legend(frameon=False, fontsize=6.3, loc="upper center", handlelength=1.2, borderaxespad=0.2, labelspacing=0.25)
SC3 = {"S2": ("S2 full framework", "#0072B2", "-"), "S2-noAdapt": ("S2 without C5", "#D55E00", "--")}
ax = axs[1]; night(ax)
for s, (l, c, ls) in SC3.items():
    d = b3[b3.scenario == s].sort_values("hour"); ax.stairs(d.requests_per100hd.values, edges, color=c, ls=ls, lw=1.2, label=l, baseline=None)
ax.set_ylabel("All responder dispatches\nper 100 home-days"); ax.set_ylim(0, 0.8); ax.set_yticks(np.arange(0, 0.81, 0.2))
ax.legend(frameon=False, fontsize=6.3, loc="center", bbox_to_anchor=(0.63, 0.55), handlelength=1.8)
ax = axs[2]; night(ax)
for s, (l, c, ls) in SC3.items():
    d = b3[b3.scenario == s].sort_values("hour"); ax.stairs(d.wait_mean.values, edges, color=c, ls=ls, lw=1.2, label=l, baseline=None)
ax.set_yscale("log"); ax.set_ylim(0.1, 500); ax.set_yticks([0.1, 1, 10, 100]); ax.set_yticklabels(["0.1", "1", "10", "100"])
ax.set_ylabel("Mean wait for responder (min)")
sublabels(fig, list(axs), ["a", "b", "c"]); save(fig, 3)

# ------------------------------------------------------------------ Figure 4: safety-burden trade-off
H = pd.read_csv("results/main_fixed_home_bootstrap.csv", index_col=0)
P4 = {s: {k: parse(H.loc[s, k]) for k in ["ll60dev_r", "fam_100", "disp_all_100"]} for s in ABL}
fig, axs = plt.subplots(1, 2, figsize=(6.3, 3.0)); fig.subplots_adjust(left=0.10, right=0.98, bottom=0.24, top=0.84, wspace=0.28)


def pts(ax, xk, dodge={}):
    for s, (mk, c, filled, l) in ABL.items():
        y = P4[s]["ll60dev_r"]; x = P4[s][xk]; xx = x[0] + dodge.get(s, 0)
        ax.errorbar(xx, y[0], xerr=[[x[0] - x[1]], [x[2] - x[0]]], yerr=[[y[0] - y[1]], [y[2] - y[0]]], fmt=mk, ms=5.5 if mk not in ("^", "v") else 6,
                    mfc=c if filled else "white", mec=c, mew=1.0, ecolor=c, elinewidth=0.7, capsize=1.5, zorder=3)


ax = axs[0]; ax.set_xscale("log"); ax.set_xlim(1, 60); ax.set_xticks([1, 2, 5, 10, 20, 50]); ax.set_xticklabels(["1", "2", "5", "10", "20", "50"])
pts(ax, "fam_100"); ax.set_xlabel("Background-alert family notifications\nper 100 home-days"); ax.set_ylabel("Long lie ≥ 60 min\n(device-signalled falls)")
ax = axs[1]; ax.set_xlim(-0.8, 12.5); pts(ax, "disp_all_100", dodge={"S1": -0.45, "S1-personal": -0.15, "S2-noEscalate": 0.3})
nv = P4["S2-noVerify"]; ax.annotate("unstable queue", (nv["disp_all_100"][0], nv["ll60dev_r"][0]), xytext=(0, -11), textcoords="offset points", ha="center", va="center", fontsize=6.3, color="#009E73")
ax.set_xlabel("All responder dispatches\nper 100 home-days")
for ax in axs: ax.set_ylim(0, 0.8); ax.set_yticks(np.arange(0, 0.81, 0.2))
hd = [Line2D([], [], ls="none", marker=mk, ms=5.5, mfc=c if f else "white", mec=c, mew=1.0, label=l) for s, (mk, c, f, l) in ABL.items()]
order = [0, 4, 1, 5, 2, 6, 3, 7]
fig.legend([hd[i] for i in order], [hd[i].get_label() for i in order], loc="upper center", bbox_to_anchor=(0.54, 1.02), ncol=4, frameon=False, fontsize=6.3,
           handletextpad=0.3, columnspacing=1.0, labelspacing=0.5)
sublabels(fig, list(axs), ["a", "b"]); save(fig, 4)

# ------------------------------------------------------------------ Figure 5: representative timelines
t5 = pd.read_csv("results/fig5_timeline_examples.csv")
PH = {"wait": ("#d9d9d9", "Awaiting response"), "fam": (COL["S1"], "Family travel"), "resp": (COL["S2"], "Responder queue and travel")}


def segs(r, s):
    det, fa, req, help_ = r[f"{s}_detect"], r[f"{s}_first"], r[f"{s}_req"], r[f"{s}_help"]
    return ([("wait", det, req), ("resp", req, help_)] if not np.isnan(req) else [("wait", det, fa), ("fam", fa, help_)]), help_


def hhmm(h): return f"{int(h):02d}:{int(round((h % 1) * 60)):02d}"


TXT = ["Day, family member reachable", "Day, family member unreachable", "Night, family member unreachable"]; XL = [100, 100, 500]
fig, axs = plt.subplots(3, 1, figsize=(6.3, 4.9)); fig.subplots_adjust(left=0.07, right=0.97, top=0.93, bottom=0.08, hspace=0.95)
for k, ax in enumerate(axs):
    r = t5.iloc[k]
    for j, s in enumerate(["S0", "S1", "S2"]):
        y = 2 - j; sg, h = segs(r, s)
        for ph, a0, a1 in sg:
            if a1 > a0: ax.barh(y, a1 - a0, left=a0, height=0.5, color=PH[ph][0], edgecolor="none", zorder=2)
        ax.plot([h, h], [y - 0.32, y + 0.32], color="black", lw=1.2, zorder=3)
        ax.text(h + XL[k] * 0.012, y, f"{h:.0f} min", va="center", ha="left", fontsize=6.5, zorder=4,
                bbox=dict(facecolor="white", edgecolor="none", pad=0.8))
    ax.axvline(60, color="#D55E00", ls="--", lw=0.8, zorder=1)
    ax.set_yticks([2, 1, 0]); ax.set_yticklabels(["S0", "S1", "S2"]); ax.set_ylim(-0.55, 2.55); ax.set_xlim(0, XL[k])
    ax.text(1.0, 1.03, f"{TXT[k]}; fall at {hhmm(r.clock)}", transform=ax.transAxes, ha="right", va="bottom", fontsize=6.5)
    ax.set_xlabel("Time since fall (min)"); ax.tick_params(axis="y", length=0)
hs = [plt.Rectangle((0, 0), 1, 1, color=PH[p][0]) for p in PH] + [Line2D([], [], color="black", lw=1.2), Line2D([], [], color="#D55E00", ls="--", lw=0.8)]
fig.legend(hs, [PH[p][1] for p in PH] + ["Help arrives", "Long-lie threshold (60 min)"], loc="upper center", bbox_to_anchor=(0.52, 1.0), ncol=5, frameon=False,
           fontsize=6.5, handlelength=1.4, columnspacing=1.0)
sublabels(fig, list(axs), ["a", "b", "c"]); save(fig, 5)

# ------------------------------------------------------------------ Figure 6: component ablation
D6 = pd.read_csv("results/main_fixed_paired_differences.csv", index_col=0)
ROWS = [("S2-noVerify vs S2", "S2-noVerify", "S2 − C1†"), ("S2-noEscalate vs S2", "S2-noEscalate", "S2 − C3"), ("S2-noTier vs S2", "S2-noTier", "S2 − C4"), ("S2-noAdapt vs S2", "S2-noAdapt", "S2 − C5")]
OUT = [("ll60dev_r", "Δ Long lie ≥ 60 min\n(device-signalled falls)"), ("fam_100", "Δ Background-alert\nfamily notifications\nper 100 home-days"),
       ("fam_night_100", "Δ Night-time background-\nalert family notifications\nper 100 home-days"), ("disp_all_100", "Δ All responder\ndispatches\nper 100 home-days")]
fig, axs = plt.subplots(1, 4, figsize=(6.3, 2.4), sharey=True); fig.subplots_adjust(left=0.10, right=0.99, bottom=0.40, top=0.97, wspace=0.22)
for j, (k, xl) in enumerate(OUT):
    ax = axs[j]; ax.axvline(0, color="#555555", lw=0.7, zorder=1)
    for i, (key, s, lab) in enumerate(ROWS):
        e, lo, hi = parse(D6.loc[key, k]); mk, c, _, _ = ABL[s]
        ax.errorbar(e, 3 - i, xerr=[[e - lo], [hi - e]], fmt=mk, ms=5.5 if mk not in ("^", "v") else 6, mfc="white", mec=c, mew=1.0, ecolor=c, elinewidth=0.9, capsize=2, zorder=3)
    ax.set_xlabel(xl); ax.tick_params(axis="y", length=0)
axs[0].set_yticks([3, 2, 1, 0]); axs[0].set_yticklabels([r[2] for r in ROWS]); axs[0].set_ylim(-0.6, 3.6)
axs[0].set_xlim(-0.05, 0.32); axs[1].set_xlim(-1, 8.5); axs[2].set_xlim(-0.5, 2.5); axs[3].set_xlim(-3, 10.5)
sublabels(fig, list(axs), ["a", "b", "c", "d"]); save(fig, 6)

# ------------------------------------------------------------------ Figure 7: policy and parameter sweeps
sc_ = pd.read_csv("results/sweep_c.csv"); ss = pd.read_csv("results/sweep_s.csv"); sp = pd.read_csv("results/sweep_pn.csv")


def line(ax, x, y, s, se=None):
    mk, c, filled, l = ABL[s]; ax.plot(x, y, color=c, lw=1.0, zorder=2)
    if se is not None:   # 95% Monte Carlo interval of each point
        ax.errorbar(x, y, yerr=1.96 * np.asarray(se), fmt="none", ecolor=c, elinewidth=0.7, capsize=1.5, zorder=2)
    for xi, yi in zip(x, y):
        ax.plot(xi, yi, marker=mk, ms=5 if mk not in ("^", "v") else 5.5, mfc=c if filled else "white", mec=c, mew=1.0, ls="none", zorder=3)


TCg = pd.read_csv("results/travel_responders.csv"); CV = [30, 45, 60, 75, 90]; NV = [1, 2, 3, 4]
fig, axs = plt.subplots(2, 2, figsize=(6.3, 5.0)); fig.subplots_adjust(left=0.10, right=0.97, top=0.91, bottom=0.10, hspace=0.62, wspace=0.42); axs = axs.ravel()
Dm = np.array([[100 * TCg[(TCg.C == Cv) & (TCg.c == n)].d_ll60_device_vs_S1P.iloc[0] for n in NV] for Cv in CV])
Lo = np.array([[100 * TCg[(TCg.C == Cv) & (TCg.c == n)].d_ll60_device_vs_S1P_lo.iloc[0] for n in NV] for Cv in CV])
Hi = np.array([[100 * TCg[(TCg.C == Cv) & (TCg.c == n)].d_ll60_device_vs_S1P_hi.iloc[0] for n in NV] for Cv in CV])
Rh = np.array([[TCg[(TCg.C == Cv) & (TCg.c == n)].S2_util.iloc[0] for n in NV] for Cv in CV])
vm = np.ceil(np.nanmax(np.abs(Dm)) / 5) * 5
im0 = axs[0].imshow(Dm, cmap="RdBu_r", vmin=-vm, vmax=vm, origin="lower", aspect="auto")
im1 = axs[1].imshow(np.minimum(Rh, 1.5), cmap="Greys", vmin=0, vmax=1.5, origin="lower", aspect="auto")
for i in range(len(CV)):
    for j in range(len(NV)):
        sig = (Hi[i, j] < 0) or (Lo[i, j] > 0)
        axs[0].text(j, i, f"{Dm[i, j]:+.1f}".replace("-", "\u2212") + ("" if sig else "*"), ha="center", va="center", fontsize=6.3,
                    color="white" if abs(Dm[i, j]) > 0.6 * vm else "black")
        axs[1].text(j, i, f"{Rh[i, j]:.2f}" + (" ≥ 1" if Rh[i, j] >= 1 else ""), ha="center", va="center", fontsize=6.3,
                    color="white" if min(Rh[i, j], 1.5) > 0.8 else "black")
for ax in axs[:2]:
    ax.set_xticks(range(len(NV))); ax.set_xticklabels(NV); ax.set_yticks(range(len(CV))); ax.set_yticklabels(CV)
    ax.set_xlabel("Number of community responders, c"); ax.set_ylabel("Mean responder travel time, C (min)")
    ax.add_patch(plt.Rectangle((0.5, 0.5), 1, 1, fill=False, ec="#D55E00", lw=1.2))   # base case C = 45, c = 2
cb = fig.colorbar(im0, ax=axs[0], fraction=0.06, pad=0.03); cb.set_label("Δ long lie, S2-P − S1-P\n(percentage points)", fontsize=6.5); cb.ax.tick_params(labelsize=6.3)
cb = fig.colorbar(im1, ax=axs[1], fraction=0.06, pad=0.03); cb.set_label("Demand load ratio of S2-P, ρ", fontsize=6.5); cb.ax.tick_params(labelsize=6.3)
for s in ["S0", "S1", "S1-personal", "S2"]:
    d = ss[ss.scenario == s].sort_values("s"); line(axs[2], d.s, d.long_lie60, s, d.long_lie60_se)
axs[2].set_xlim(-0.04, 0.94); axs[2].set_xticks([0, 0.25, 0.5, 0.75, 0.9]); axs[2].set_xticklabels(["0", "0.25", "0.5", "0.75", "0.9"]); axs[2].set_ylim(0, 1.05)
axs[2].set_xlabel("Share of falls signalled by a wearable device, s"); axs[2].set_ylabel("Long lie ≥ 60 min\n(all falls)")
for s in ["S1", "S1-personal", "S2-noTier", "S2"]:
    d = sp[sp.scenario == s].sort_values("p_night"); line(axs[3], d.p_night, d.ll60_device, s, d.ll60_device_se)
axs[3].set_xlim(0.15, 0.85); axs[3].set_xticks([0.2, 0.35, 0.5, 0.65, 0.8]); axs[3].set_ylim(0, 0.3)
axs[3].set_xlabel("Night-time reachability of family member, $p_{night}$"); axs[3].set_ylabel("Long lie ≥ 60 min\n(device-signalled falls)")
used = ["S0", "S1", "S1-personal", "S2", "S2-noTier"]
hd = [Line2D([], [], color=ABL[s][1], lw=1.0, marker=ABL[s][0], ms=5, mfc=ABL[s][1] if ABL[s][2] else "white", mec=ABL[s][1], label=ABL[s][3]) for s in used]
fig.legend(hd, [h.get_label() for h in hd], loc="upper center", bbox_to_anchor=(0.54, 0.505), ncol=3, frameon=False, fontsize=6.3, handlelength=1.8, columnspacing=1.2)
sublabels(fig, list(axs), ["a", "b", "c", "d"]); save(fig, 7)

# ------------------------------------------------------------------ Figure 8: global sensitivity analysis
gs = pd.read_csv("results/gsa_set_level.csv"); pr = pd.read_csv("results/gsa_prcc.csv")
PR = {y: {r.parameter: (r.prcc, r.p) for r in pr[pr.outcome == y].itertuples()} for y in ["d_ll60_P", "d_ll60_dev_P"]}
PAR = list(PR["d_ll60_P"]); thr = 0.001 / 13
PLAB = {"C": "Responder travel time, $C$", "c": "Number of responders, $c$", "F": "Family travel time, $F$", "s": "Device-signalled share, $s$",
        "q_b": "Benign-alert answer prob., $q_b$", "p_day": "Day reachability, $p_{day}$", "W_day": "Passive noticing delay, $W_{day}$",
        "q_f": "Fallen-resident answer prob., $q_f$", "S_b": "Service time (benign), $S_b$", "p_night": "Night reachability, $p_{night}$",
        "A": "Acknowledgement delay, $A$", "lam": "Fall rate, $\\lambda$", "S_f": "Service time (fall), $S_f$"}
order = sorted(PAR, key=lambda p: abs(PR["d_ll60_P"][p][0]))
fig, axs = plt.subplots(1, 2, figsize=(6.3, 3.1)); fig.subplots_adjust(left=0.29, right=0.985, bottom=0.25, top=0.88, wspace=0.50)
ax = axs[0]; h = 0.38
SER = [("d_ll60_P", "All falls", "#0072B2", +h / 2), ("d_ll60_dev_P", "Device-signalled falls", "#E69F00", -h / 2)]
for k, l, c, off in SER:
    for i, p in enumerate(order):
        r, pv = PR[k][p]; ax.barh(i + off, r, height=h, color=c if pv < thr else "white", edgecolor=c, lw=0.8, zorder=2)
ax.axvline(0, color="#555555", lw=0.7)
ax.set_yticks(np.arange(len(order))); ax.set_yticklabels([PLAB[p] for p in order]); ax.set_ylim(-0.6, len(order) - 0.4)
ax.set_xlim(-0.85, 0.85); ax.set_xticks([-0.8, -0.4, 0, 0.4, 0.8]); ax.set_xlabel("PRCC with Δ long lie (S2-P − S1-P)"); ax.tick_params(axis="y", length=0)
ax = axs[1]
CC = {1: cm.viridis(0.92), 2: cm.viridis(0.62), 3: cm.viridis(0.35), 4: cm.viridis(0.05)}
ax.axhspan(0, 0.25, color="#f2f2f2", zorder=0, lw=0)
for cv in [1, 2, 3, 4]:
    d = gs[gs.c == cv]; ind = d.d_ll60_P_class == "indeterminate"
    ax.scatter(d.C[~ind], d.d_ll60_P[~ind], s=9, color=CC[cv], edgecolor="#333333", lw=0.3, label=f"c = {cv}", zorder=3)
    ax.scatter(d.C[ind], d.d_ll60_P[ind], s=9, facecolor="white", edgecolor=CC[cv], lw=0.7, zorder=3)
ax.axhline(0, color="#555555", lw=0.7)
yl = (np.floor(gs.d_ll60_P.min() * 20) / 20 - 0.03, np.ceil(gs.d_ll60_P.max() * 20) / 20 + 0.03)
ax.text(31, yl[1] - 0.01, "S2-P worse than S1-P", fontsize=6.5, va="top", color="#555555"); ax.text(45, yl[0] + 0.02, "S2-P better than S1-P", fontsize=6.5, va="bottom", ha="left", color="#555555")
ax.set_xlim(29, 61); ax.set_ylim(*yl); ax.set_xlabel("Responder travel time, $C$ (min)"); ax.set_ylabel("Δ long lie ≥ 60 min, S2-P − S1-P\n(all falls)")
hh, ll = ax.get_legend_handles_labels()
hh.append(Line2D([], [], marker="o", ls="none", mfc="white", mec="#333333", ms=3.4, mew=0.7)); ll.append("95% MC interval\nincludes 0")
ax.legend(hh, ll, loc="lower right", frameon=False, fontsize=6.3, handletextpad=0.2, borderaxespad=0.2, markerscale=1.2, bbox_to_anchor=(1.0, 0.07))
fig.legend(handles=[Patch(fc=c, ec=c, label=l) for k, l, c, o in SER] + [Patch(fc="white", ec="#555555", label="Not significant")], loc="upper center",
           bbox_to_anchor=(0.40, 1.0), ncol=3, frameon=False, fontsize=6.3, handlelength=1.2, columnspacing=1.2)
sublabels(fig, list(axs), ["a", "b"]); save(fig, 8)
print("figures written to figures/")
