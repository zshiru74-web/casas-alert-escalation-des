"""Step 1. Convert the CASAS raw release to one Parquet file per home.

Download the raw release (Cook, Zenodo, https://doi.org/10.5281/zenodo.16343844) and place its zip
archives in data/raw/. Archives may contain the same home twice; identical files are converted once.
Outputs: data/homes/<home>.parquet, data/home_index.csv, data/sensor_inventory.csv
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import glob, json, os, shutil, zipfile
import pandas as pd
from _common import run_parallel

zips = sorted(glob.glob("data/raw/*.zip"))
assert zips, "place the raw CASAS zip archives in data/raw/"
entries = {}
for zp in zips:
    for info in zipfile.ZipFile(zp).infolist():
        if info.filename.endswith(".txt") and "/" not in info.filename:
            entries.setdefault(info.filename, (zp, info.file_size))
jobs = [[f[:-4], zp, f, os.path.basename(zp), size] for f, (zp, size) in sorted(entries.items())]
json.dump(jobs, open("data/_jobs.json", "w"))
print(len(jobs), "homes")
run_parallel([["src/convert_casas.py", "data/_jobs.json", str(i)] for i in range(len(jobs))], label="convert")

idx = pd.DataFrame([json.load(open(f)) for f in glob.glob("data/_meta/*.json")]).sort_values("home").reset_index(drop=True)
inv = pd.concat([pd.read_csv(f) for f in glob.glob("data/_meta/*_inv.csv")], ignore_index=True)
named = ~inv.sensor.astype(str).str.match(r"^[A-Z]{1,3}\d{2,4}[A-Z]?$")
style = named.groupby(inv.home).mean()
idx["sensor_naming"] = idx.home.map(lambda h: "location-named" if style.get(h, 0) > 0.5 else "coded-ID")
idx.drop(columns=["bad_examples", "n_bad_ts"]).rename(columns={"n_bad_rows": "n_rows_extra_fields"}).to_csv("data/home_index.csv", index=False)
inv.to_csv("data/sensor_inventory.csv", index=False)
shutil.rmtree("data/_meta")
print(f"events: {idx.n_events.sum():,}; period {idx.start.min()[:10]} to {idx.end.max()[:10]}")
