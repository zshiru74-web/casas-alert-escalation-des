"""Shared helpers: run every script from the repository root and run worker scripts in parallel."""
import os, sys, subprocess, time

ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
os.chdir(ROOT)
sys.path.insert(0, os.path.join(ROOT, "src"))
NPROC = max(1, (os.cpu_count() or 2) - 2)


def run_parallel(cmds, maxp=NPROC, label=""):
    """Run python worker commands (lists of arguments) in parallel subprocesses."""
    running, fails, queue, t0 = [], [], list(cmds), time.time()
    while queue or running:
        while queue and len(running) < maxp:
            c = queue.pop(0)
            running.append((c, subprocess.Popen([sys.executable] + c, stdout=subprocess.DEVNULL,
                                                stderr=subprocess.PIPE, text=True)))
        for c, p in running[:]:
            if p.poll() is not None:
                running.remove((c, p)); err = p.stderr.read()
                if p.returncode:
                    fails.append((c, err[-500:]))
        time.sleep(0.5)
    print(f"{label} {len(cmds)} jobs finished in {time.time() - t0:.0f} s; failures: {len(fails)}")
    for c, e in fails:
        print("FAILED:", c, e)
    if fails:
        sys.exit(1)
