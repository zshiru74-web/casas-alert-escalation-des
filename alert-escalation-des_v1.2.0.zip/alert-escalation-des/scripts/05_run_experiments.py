"""Step 5. Simulation experiments (Sections 2.6-2.8 of the paper). Results go to results/<experiment>/.

All experiments use fixed seeds (replication r of the main experiment uses numpy.random.default_rng([20261116, r])),
so rerunning this script reproduces the reported numbers. Run time on a 16-core desktop: roughly 1 h.

Model variants used in the decomposition of the model revision (all other experiments use the final model, V2):
  V0  falls drawn from any evaluation day of the home; original timing rules
  V1  falls drawn from the historical day replayed on the fall day; the fallen resident's benign alerts are removed
      for 24 h after the fall
  V2  V1 + unified timing (device alerts skip the check call in every policy; day/night by notification time)
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import json, os
from _common import run_parallel
import des_sim as ds
import gsa


def J(exp, r0, r1, boot, over=None, scen=None, root=None):
    return (["src/run_batch.py", exp, str(r0), str(r1), "1" if boot else "0", json.dumps(over or {}),
             json.dumps(scen or list(ds.SCENARIOS))] + ([root] if root else []))


jobs = [J("main_fixed", r, r + 50, False) for r in range(0, 500, 50)]          # home-level outcomes, 500 reps
jobs += [J("main_boot", r, r + 100, True) for r in range(0, 1000, 100)]        # system-level outcomes, homes resampled
for c in [1, 2, 3, 4]:
    jobs += [J(f"sw_c{c}", r, r + 100, False, {"c": c}, ["S2", "S2-noAdapt", "S2-noVerify", "S2-noTier"]) for r in range(0, 200, 100)]
for sv in [0.0, 0.25, 0.5, 0.75, 0.9]:
    jobs += [J(f"sw_s{sv}", r, r + 100, False, {"s": sv}, ["S0", "S1", "S1-personal", "S2"]) for r in range(0, 200, 100)]
for L in [5, 10, 15, 30]:
    jobs += [J(f"sw_L{L}", r, r + 100, False, {"L_r": float(L)}, ["S2"]) for r in range(0, 200, 100)]
for pn in [0.2, 0.35, 0.5, 0.65, 0.8]:
    jobs += [J(f"sw_pn{pn}", r, r + 100, False, {"p_night": pn}, ["S1", "S1-personal", "S2", "S2-noTier"]) for r in range(0, 200, 100)]
# joint sensitivity: responder travel time C (mean, min) x number of responders c (200 reps each)
for C in [30, 45, 60, 75, 90]:
    for c in [1, 2, 3, 4]:
        jobs += [J(f"tc_C{C}_c{c}", r, r + 100, False, {"C": float(C), "c": c}, ["S1", "S1-personal", "S2"]) for r in range(0, 200, 100)]
# responder schedules by time of day (Table 5): c_day responders 06:00-22:00, c_night responders 22:00-06:00
STAFF = [(1, 1), (2, 1), (1, 2), (2, 2), (1, 3), (2, 3)]
for cd, cn in STAFF:
    jobs += [J(f"staff_d{cd}n{cn}", r, r + 50, False, {"c_day": cd, "c_night": cn}, ["S2"]) for r in range(0, 200, 50)]
# decomposition of the model revision (same seeds as main_fixed and staff_*, i.e. paired)
VARIANTS = {"V0": dict(align_falls=False, drop_after_fall_h=0.0, unified_timing=False),
            "V1": dict(align_falls=True, drop_after_fall_h=24.0, unified_timing=False)}
for v, o in VARIANTS.items():
    jobs += [J(f"dec_{v}", r, r + 50, False, o, ["S0", "S1", "S2", "S2-noVerify"]) for r in range(0, 500, 50)]
    for cd, cn in STAFF:
        jobs += [J(f"decstaff_{v}_d{cd}n{cn}", r, r + 100, False, dict(o, c_day=cd, c_night=cn), ["S2"]) for r in range(0, 200, 100)]
run_parallel(jobs, label="main experiments, policy sweeps, schedules, and decomposition")

# detection-parameter sensitivity: rebuild alert streams with other threshold settings
SETTINGS = {"det_b1.0": ("1.0", "60", "max"), "det_b1.5": ("1.5", "60", "max"), "det_w30": ("1.2", "30", "max"), "det_w90": ("1.2", "90", "max")}
run_parallel([["src/build_derived.py", f"data/derived_{k}", *v] for k, v in SETTINGS.items()], maxp=4, label="detection settings")
jobs = [J(f"sens_{k}", r, r + 100, False, None, ["S1", "S1-personal", "S2", "S2-noAdapt"], f"data/derived_{k}") for k in SETTINGS for r in range(0, 200, 100)]
os.makedirs("results", exist_ok=True)
gsa.design(256).to_csv("results/gsa_design.csv", index=False)                  # Latin hypercube, seed 7
jobs += [["src/gsa.py", str(i), str(i + 16), "10"] for i in range(0, 256, 16)]
jobs += [["src/warmup_check.py", str(r), str(r + 50)] for r in range(0, 500, 50)]
jobs += [["src/informal_discovery.py", str(r), str(r + 50)] for r in range(0, 500, 50)]
os.makedirs("results/extra", exist_ok=True)
jobs += [["src/sim_extra.py", str(r), str(r + 20), f"results/extra/extra_{r:03d}.csv"] for r in range(0, 200, 20)]
run_parallel(jobs, label="sensitivity, GSA, validation, and supplementary experiments")

# GSA: sets whose S2 - S1 or S2 - S1-personal difference in long lie is within 2 Monte Carlo SE of zero get replications 10-99
ext = gsa.indeterminate_sets("results/gsa", k=2.0)
print(f"GSA sets with |mean difference| < 2 SE after 10 replications: {len(ext)}")
chunks = [ext[i::NCH] for NCH in [min(len(ext), 16)] for i in range(NCH)] if ext else []
run_parallel([["src/gsa.py", str(1000 + i), "0", "100", "10", ",".join(map(str, ch))] for i, ch in enumerate(chunks) if ch],
             label="GSA additional replications")
