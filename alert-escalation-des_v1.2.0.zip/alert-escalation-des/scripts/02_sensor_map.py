"""Step 2. Link raw sensor identifiers to rooms using the officially mapped release
(Cook, Zenodo, https://doi.org/10.5281/zenodo.15708568).

Each raw event is matched to the mapped event with the same time stamp and state; a mapping is accepted
only if every raw sensor corresponds to a single room label. The mapped data.zip is read member by member
with HTTP range requests, so the full archive does not need to be downloaded.
Outputs: data/sensor_map/<home>.csv|json, data/sensor_map_final/sensor_location_map.csv
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import json, os
import numpy as np, pandas as pd, requests
from _common import run_parallel

rec = requests.get("https://zenodo.org/api/records/15708568", timeout=60).json()
url = [f for f in rec["files"] if f["key"] == "data.zip"][0]["links"]["self"]
CAND = [f"hh{i}" for i in range(109, 131)] + ["rw101", "rw102", "rw103", "rw104", "rw105", "rw106", "rw107", "mv001", "navan"]
CAND = [h for h in CAND if os.path.exists(f"data/homes/{h}.parquet")]
os.makedirs("data/sensor_map", exist_ok=True)
run_parallel([["src/fetch_map.py", url, h] for h in CAND], maxp=6, label="sensor-map alignment")

# Homes documented as occupied by one older adult (dataset documentation). Excluded: hh121, rw104, milan,
# tulum (2 residents); paris, laval (>2 residents); rw102, mva001-mva004 (residents unknown or not
# documented); navan (adult, not older-adult cohort).
ELIG = [f"hh{i}" for i in range(109, 121)] + [f"hh{i}" for i in range(122, 131)] + ["rw101", "rw103", "rw105", "rw106", "rw107", "mv001"]
inv = pd.read_csv("data/sensor_inventory.csv")
smap = pd.concat([pd.read_csv(f"data/sensor_map/{h}.csv") for h in ELIG], ignore_index=True)
assert smap.groupby(["home", "sensor_raw"]).sensor_map.nunique().max() == 1, "a raw sensor maps to several rooms"
sm = smap.merge(inv[["home", "sensor", "n", "states"]].rename(columns={"sensor": "sensor_raw", "n": "n_total"}), on=["home", "sensor_raw"], how="left")


def stype(s):
    s = str(s)
    if "OPEN" in s or "CLOSE" in s:
        return "door"
    if "ON" in s and "OFF" in s and not any(ch.isdigit() for ch in s.replace("ON", "").replace("OFF", "").replace("|", "")):
        return "motion"
    return "other"


def loc_class(name):
    n = str(name)
    if n.startswith("Bathroom"): return "Bathroom"
    if n.startswith("Bedroom"): return "Bedroom"
    if n.startswith("Kitchen"): return "Kitchen"
    if n in ("OutsideDoor", "MainDoor", "MainEntryway") or n.startswith("Entryway"): return "Entry"
    return "Living"   # LivingRoom*, DiningRoom*, Office*, WorkArea, Chair, Hall*, LaundryRoom*


sm["type"] = sm.states.map(stype)
sm["loc"] = sm.sensor_map.map(loc_class)
sm["role"] = np.where(sm.type == "motion", "motion", np.where((sm.type == "door") & (sm["loc"] == "Entry"), "exitdoor",
                      np.where(sm.type == "door", "innerdoor", "other")))
os.makedirs("data/sensor_map_final", exist_ok=True)
sm.to_csv("data/sensor_map_final/sensor_location_map.csv", index=False)
st = pd.DataFrame([json.load(open(f"data/sensor_map/{h}.json")) for h in ELIG])
print("event match rate:", (st.n_unique_keys / st.n_raw).min().round(4), "-", (st.n_unique_keys / st.n_raw).max().round(4))
