"""Step 4. Causal alert streams (fixed, generic, personal configurations) and the fall library.

Outputs: data/derived/benign_{fixed,generic,personal}.parquet, data/derived/fall_library.parquet,
data/derived/meta.json (included homes and number of evaluation days per home)
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import json, os
import numpy as np, pandas as pd
import _common  # noqa: F401
import pipeline_events as pe

vs = pd.read_csv("data/home_inclusion.csv", index_col=0)
INCL = vs.index[vs.included].tolist()
HOMES = {h: pe.Home(h) for h in INCL}


def build_all(buffer=1.2, stat="max", win=60, nf=3000, seed=20261116):
    det, pp = {}, {}
    for h in INCL:
        d = pe.Detector(HOMES[h], "personal", buffer=buffer, win=win)
        if stat != "max":
            d.T = HOMES[h].e2_profiles(buffer, win, stat=stat)
        det[(h, "personal")] = d; pp[h] = np.nanmedian(d.T[pe.BURN:], axis=0)
    for h in INCL:   # generic profile: leave-one-home-out median of the other homes' personal profiles
        gp = np.nanmedian(np.vstack([pp[o] for o in INCL if o != h]), axis=0)
        det[(h, "generic")] = pe.Detector(HOMES[h], "generic", generic_profile=gp)
        det[(h, "fixed")] = pe.Detector(HOMES[h], "fixed")
    ben = {cfg: pd.concat([det[(h, cfg)].benign_alerts() for h in INCL], ignore_index=True) for cfg in ["fixed", "generic", "personal"]}
    rng = np.random.default_rng(seed); lib = []
    for h in INCL:   # candidate falls at motion events on evaluation days (activity-weighted)
        H = HOMES[h]; dd = pe.dayns(H.mt); elig = np.where(np.isin(dd, np.fromiter(H.evalset, dtype=np.int64)))[0]
        for j in np.sort(rng.choice(elig, nf, replace=False)):
            rec = dict(home=h, j=int(j), loc=int(H.ml[j]), vday=H.vidx[int(pe.dayns(H.mt[j]))], min_of_day=(H.mt[j] - pe.dayns(H.mt[j])) / pe.NS_MIN)
            for cfg in ["fixed", "generic", "personal"]:
                dl, rule = det[(h, cfg)].fall_detection(j); rec[f"det_{cfg}"] = dl; rec[f"rule_{cfg}"] = rule
            lib.append(rec)
    fl = pd.DataFrame(lib); fl["night"] = (fl.min_of_day >= 22 * 60) | (fl.min_of_day < 6 * 60)
    return det, ben, fl


def build_day_library(det, m=8, seed=20261117):
    """Fall library aligned with the replayed day: m candidate falls on every evaluation day of every home
    (uniform over days, activity-weighted within a day). e is the index of the evaluation day, the same index
    that places the benign alerts of that day in the virtual year."""
    rows = []
    for hi, h in enumerate(INCL):
        H = HOMES[h]; rng = np.random.default_rng([seed, hi])
        for d in H.vdays[pe.BURN:]:
            a, b = np.searchsorted(H.mt, d), np.searchsorted(H.mt, d + pe.NS_DAY)
            if b <= a:
                continue
            for j in np.sort(rng.integers(a, b, m)):
                rec = dict(home=h, e=H.vidx[int(d)] - pe.BURN, j=int(j), loc=int(H.ml[j]), min_of_day=(H.mt[j] - d) / pe.NS_MIN)
                for cfg in ["fixed", "generic", "personal"]:
                    dl, rule = det[(h, cfg)].fall_detection(int(j)); rec[f"det_{cfg}"] = dl; rec[f"rule_{cfg}"] = rule
                rows.append(rec)
    dl = pd.DataFrame(rows); dl["night"] = (dl.min_of_day >= 22 * 60) | (dl.min_of_day < 6 * 60)
    return dl


DET, BEN, FL = build_all()
DL = build_day_library(DET)
eval_len = {h: len(HOMES[h].evalset) for h in INCL}
os.makedirs("data/derived", exist_ok=True)
for cfg, A in BEN.items():
    A.to_parquet(f"data/derived/benign_{cfg}.parquet", index=False)
FL.to_parquet("data/derived/fall_library.parquet", index=False)
DL.to_parquet("data/derived/fall_library_day.parquet", index=False)
json.dump(dict(eval_len=eval_len, homes=INCL), open("data/derived/meta.json", "w"))
evd = sum(eval_len.values())
for cfg in ["fixed", "generic", "personal"]:
    d = FL[f"det_{cfg}"]
    print(cfg, "alerts/100 home-days", round(len(BEN[cfg]) / evd * 100, 2), "median detection delay", round(d.median()), "min")
print("evaluation home-days:", evd)
miss = sum(len(HOMES[h].evalset) for h in INCL) - DL.groupby(["home", "e"]).ngroups
for cfg in ["fixed", "generic", "personal"]:
    d = DL[f"det_{cfg}"]
    print(f"day library {cfg}: median delay {d.median():.0f} min, <=60 min {100 * (d <= 60).mean():.2f}%, "
          f"not detected in 48 h {100 * d.isna().mean():.2f}%")
print("day-library candidates:", len(DL), "evaluation days without motion events:", miss)
