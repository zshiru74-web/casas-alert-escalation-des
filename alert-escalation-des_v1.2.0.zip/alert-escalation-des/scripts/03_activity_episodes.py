"""Step 3. Activity streams, day-level quality control, home inclusion, and episodes.

Outputs: data/activity/<home>.parquet (kind 0 motion, 1 exterior door open, 2 close; loc 0 bathroom,
1 bedroom, 2 kitchen, 3 living, 4 entry), data/daily_qc.parquet, data/home_inclusion.csv,
data/episodes/<home>_{days,gaps,bath,nightexit}.parquet
"""
import os as _os, sys as _sys
_sys.path.insert(0, _os.path.dirname(_os.path.abspath(__file__)))

import os
import numpy as np, pandas as pd
import _common  # noqa: F401  (sets the working directory)

LOC = {"Bathroom": 0, "Bedroom": 1, "Kitchen": 2, "Living": 3, "Entry": 4}
NO_DOOR = ("hh122", "rw106", "rw107", "mv001")          # no functional exterior-door sensor
sm = pd.read_csv("data/sensor_map_final/sensor_location_map.csv")
ELIG = sorted(sm.home.unique())

# --- activity streams
os.makedirs("data/activity", exist_ok=True)
for h in ELIG:
    d = pd.read_parquet(f"data/homes/{h}.parquet"); d["sensor"] = d.sensor.astype(str); d["state"] = d.state.astype(str)
    mh = sm[sm.home == h].set_index("sensor_raw")
    d = d[d.sensor.isin(mh.index)].copy()
    d["role"] = d.sensor.map(mh.role); d["loc"] = d.sensor.map(mh["loc"])
    mot = d[(d.role == "motion") & (d.state == "ON")]
    door = d[(d.role == "exitdoor") & (d.state.isin(["OPEN", "CLOSE"]))]
    out = pd.concat([pd.DataFrame({"ts": mot.ts, "kind": np.int8(0), "loc": mot["loc"].map(LOC).astype("int8")}),
                     pd.DataFrame({"ts": door.ts, "kind": np.where(door.state == "OPEN", 1, 2).astype("int8"), "loc": np.int8(4)})]
                    ).sort_values("ts", kind="stable").reset_index(drop=True)
    out.to_parquet(f"data/activity/{h}.parquet", index=False)

# --- day-level quality control
daily = []
for h in ELIG:
    a = pd.read_parquet(f"data/activity/{h}.parquet"); a["day"] = a.ts.dt.normalize()
    m = a[a.kind == 0]; g = m.groupby("day")
    dd = pd.DataFrame({"n_motion": g.size(), "hours_active": g.ts.apply(lambda s: s.dt.hour.nunique())})
    for l, c in LOC.items():
        dd[f"n_{l}"] = m[m["loc"] == c].groupby("day").size()
    dd["n_door"] = a[a.kind > 0].groupby("day").size()
    allts = a.ts.values
    gaps = np.diff(allts).astype("timedelta64[s]").astype(float) / 60
    dd["max_gap_min"] = pd.Series(gaps, index=pd.DatetimeIndex(allts[:-1]).normalize()).groupby(level=0).max()
    dd = dd.reindex(pd.date_range(a.day.min(), a.day.max(), freq="D")).fillna(0)
    dd["home"] = h; dd.index.name = "day"; daily.append(dd.reset_index())
daily = pd.concat(daily, ignore_index=True)
med = daily[daily.n_motion > 0].groupby("home").n_motion.median()
daily["rel"] = daily.n_motion / daily.home.map(med)
# valid day: >= 25% of the home's median motion count, and bathroom plus kitchen or living-area activity
daily["valid"] = (daily.rel >= 0.25) & (daily.n_Bathroom > 0) & ((daily.n_Kitchen + daily.n_Living) > 0)
daily.to_parquet("data/daily_qc.parquet", index=False)
vs = daily.groupby("home").agg(days=("day", "size"), valid=("valid", "sum"))
vs["included"] = vs.valid >= 90
vs.to_csv("data/home_inclusion.csv")
INCL = vs.index[vs.included].tolist()
print("included homes:", len(INCL), "valid days:", int(vs.loc[vs.included, "valid"].sum()))


def door_ok_days(dh):   # exterior-door sensor functional if it recorded an event within +-3 days
    return dh.set_index("day").n_door.rolling(7, center=True, min_periods=1).sum() > 0


def hour_f(ts):
    t = pd.DatetimeIndex(ts); return t.hour + t.minute / 60 + t.second / 3600


def is_night(hf): return (hf >= 22) | (hf < 6)


os.makedirs("data/episodes", exist_ok=True)
for h in INCL:
    a = pd.read_parquet(f"data/activity/{h}.parquet")
    dh = daily[daily.home == h].copy(); dok = door_ok_days(dh)
    has_door_home = h not in NO_DOOR
    dh["door_ok"] = dok.values & has_door_home
    dh[["day", "valid", "door_ok", "n_motion"]].to_parquet(f"data/episodes/{h}_days.parquet", index=False)
    mot = a[a.kind == 0].reset_index(drop=True); door_open = a.loc[a.kind == 1, "ts"].values
    t = mot.ts.values; loc = mot["loc"].values
    # inactivity gaps (>= 30 min) between consecutive motion events
    ts_, te_ = t[:-1], t[1:]
    dur = (te_ - ts_).astype("timedelta64[ms]").astype(float) / 60000
    keep = dur >= 30
    ts_, te_, dur, lastloc, nextloc = ts_[keep], te_[keep], dur[keep], loc[:-1][keep], loc[1:][keep]
    i0 = np.searchsorted(door_open, ts_, side="right"); i1 = np.searchsorted(door_open, te_, side="left")
    pd.DataFrame({"t_s": ts_, "t_e": te_, "dur": dur, "last_loc": lastloc, "next_loc": nextloc, "n_door_open": i1 - i0}
                 ).to_parquet(f"data/episodes/{h}_gaps.parquet", index=False)
    # bathroom visits: runs of bathroom motion; the visit ends at the next non-bathroom motion
    isb = (loc == 0)
    start_idx = np.where(isb & np.r_[True, ~isb[:-1]])[0]
    end_idx = np.where(isb & np.r_[~isb[1:], True])[0]
    nxt = end_idx + 1; valid_n = nxt < len(t)
    bs = t[start_idx[valid_n]]; be = t[nxt[valid_n]]; blast = t[end_idx[valid_n]]
    bdur = (be - bs).astype("timedelta64[ms]").astype(float) / 60000
    j0 = np.searchsorted(door_open, bs, side="right"); j1 = np.searchsorted(door_open, be, side="left")
    pd.DataFrame({"t_s": bs, "t_e": be, "t_last_bath": blast, "dur": bdur, "night": is_night(hour_f(bs)),
                  "n_door_open": j1 - j0, "next_loc": loc[nxt[valid_n]]}).to_parquet(f"data/episodes/{h}_bath.parquet", index=False)
    # night exits: exterior door opened at night; absence lasts until the first non-entry motion
    if has_door_home:
        do = pd.DatetimeIndex(door_open); dn = door_open[is_night(hour_f(do))]
        nonentry_t = t[loc != 4]
        k = np.searchsorted(nonentry_t, dn, side="right"); ok = k < len(nonentry_t)
        tin = np.full(len(dn), np.datetime64("NaT"), dtype="datetime64[ns]"); tin[ok] = nonentry_t[k[ok]]
        ab = pd.DataFrame({"t_o": dn, "t_in": tin}); ab["dur"] = (ab.t_in - ab.t_o).dt.total_seconds() / 60
        keep, last_in = [], np.datetime64("1900-01-01")
        for to, ti in zip(ab.t_o.values, ab.t_in.values):   # one episode per absence
            if to < last_in:
                keep.append(False); continue
            keep.append(True); last_in = ti if not np.isnat(ti) else last_in
        ab = ab[keep].reset_index(drop=True)
    else:
        ab = pd.DataFrame(columns=["t_o", "t_in", "dur"])
    ab.to_parquet(f"data/episodes/{h}_nightexit.parquet", index=False)
print("episodes written for", len(INCL), "homes")
