"""Run replications of one experiment.
usage: python src/run_batch.py <exp> <rep0> <rep1> <boot 0|1> [overrides-json] [scenarios-json] [data-root]"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import des_sim as ds
exp, r0, r1, boot = sys.argv[1], int(sys.argv[2]), int(sys.argv[3]), sys.argv[4] == "1"
over = json.loads(sys.argv[5]) if len(sys.argv) > 5 else {}
scen = json.loads(sys.argv[6]) if len(sys.argv) > 6 else list(ds.SCENARIOS)
root = sys.argv[7] if len(sys.argv) > 7 else "data/derived"
homes, eval_len, ben, fl, dl = ds.load_inputs(root, [ds.SCENARIOS[s]["det"] for s in scen])
P = dict(ds.BASE); P.update(over)
rows, falls, perhome = [], [], []
for rep in range(r0, r1):
    rng = np.random.default_rng([20261116, rep])
    hs = list(rng.choice(homes, len(homes), replace=True)) if boot else homes
    cat = ds.Catchment(ben, fl, eval_len, hs, P, rng, dl)
    for s in scen:
        res, fh, dev = ds.run_scenario(cat, P, s)
        ph = res.pop("_per_home"); ph["rep"] = rep; ph["scenario"] = s
        ph["home_days"] = ph.index.map(lambda h: hs.count(h) * P["nv_per_home"] * P["horizon_days"])
        perhome.append(ph.reset_index())
        res.update(rep=rep, scenario=s); rows.append(res)
os.makedirs(f"results/{exp}", exist_ok=True)
pd.DataFrame(rows).to_parquet(f"results/{exp}/metrics_{r0:05d}.parquet", index=False)
pd.concat(perhome).to_parquet(f"results/{exp}/perhome_{r0:05d}.parquet", index=False)
