"""Supplementary experiments: stratified start offsets, residual benign alerts during fall episodes,
and duplicated start offsets. (Responder schedules by time of day are run by run_batch.py, see step 05.)
usage: python src/sim_extra.py <rep0> <rep1> <out.csv>"""

import sys, os, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__))); import des_sim as ds
HOMES, EVL, BEN, FL, DL = ds.load_inputs("data/derived", ["generic", "personal"])


class StratRNG:
    """Wraps a Generator; the first len(HOMES) calls to integers(0,n,k) return stratified offsets
    (no repeats, evenly spread over the evaluation period) while consuming the same draws."""
    def __init__(self, rng, aux):
        self.rng = rng; self.aux = aux; self.n = 0

    def integers(self, lo, hi=None, size=None, *a, **kw):
        x = self.rng.integers(lo, hi, size, *a, **kw)
        if self.n < len(HOMES) and size is not None and np.ndim(x) == 1 and len(x) == ds.BASE["nv_per_home"]:
            self.n += 1; k = len(x); u = self.aux.random()
            x = (np.floor((np.arange(k) + u) / k * hi).astype(np.int64))
        return x

    def __getattr__(self, name):
        return getattr(self.rng, name)


def dup_share(rng_seed):
    rng = np.random.default_rng(rng_seed); off = [rng.integers(0, EVL[h], 25) for h in HOMES]
    return float(np.mean([1 - len(np.unique(o)) / 25 for o in off]))


def one(rep):
    P = dict(ds.BASE); out = []
    seed = [20261116, rep]
    for mode in ["base", "strat"]:   # (1) offsets: base (as main analysis) vs stratified
        rng = np.random.default_rng(seed)
        r = rng if mode == "base" else StratRNG(rng, np.random.default_rng([99, rep]))
        cat = ds.Catchment(BEN, FL, EVL, HOMES, P, r, DL)
        for s in ["S0", "S1", "S2"]:
            res, fh, dev = ds.run_scenario(cat, P, s); res.pop("_per_home", None)
            out.append(dict(exp="offset", mode=mode, scenario=s, rep=rep, **{k: res[k] for k in
                       ["long_lie60", "ll60_device", "fam_notif_per100", "resp_util", "resp_wait_mean", "resp_wait_p95"]}))
        if mode == "base":
            # (2) benign alerts of the fallen virtual home that remain inside the fall episode (S2)
            res, fh, dev = ds.run_scenario(cat, P, "S2")
            B = cat.benign["personal"]; Fa = cat.falls
            byvh = {}
            for v, t in zip(B.vh.values, B.t.values):
                byvh.setdefault(v, []).append(t)
            nov = 0; falls_with = 0
            for tf, v, h in zip(Fa.t_f.values, Fa.vh.values, fh):
                ts = np.array(byvh.get(v, [])); end = tf + (h if np.isfinite(h) else 48 * 60)
                k = ((ts >= tf) & (ts < end)).sum(); nov += k; falls_with += k > 0
            out.append(dict(exp="fall_overlap", rep=rep, n_benign=len(B), n_overlap=int(nov), n_falls=len(Fa),
                            falls_with=int(falls_with), n_dropped=cat.n_benign_dropped))
            out.append(dict(exp="dup", rep=rep, dup_share=dup_share(seed)))
    return out


if __name__ == "__main__":
    r0, r1, outp = int(sys.argv[1]), int(sys.argv[2]), sys.argv[3]
    flat = [x for rep in range(r0, r1) for x in one(rep)]
    pd.DataFrame(flat).to_csv(outp, index=False); print("done", len(flat))
