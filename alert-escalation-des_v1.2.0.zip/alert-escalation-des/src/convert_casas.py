"""Convert CASAS raw text logs (in zip archives) to one Parquet file per home,
plus a home index and a sensor inventory. Duplicate members across archives
(identical CRC) are converted once."""
import sys, json, zipfile, io, os
from concurrent.futures import ProcessPoolExecutor
import pandas as pd, pyarrow as pa, pyarrow.csv as pacsv, pyarrow.parquet as pq

OUT = "data/homes"

def convert(job):
    home, zpath, member, zname = job
    with zipfile.ZipFile(zpath).open(member) as fh:
        df = pd.read_csv(fh, sep="\t", header=None, names=list(range(8)), dtype=str,
                         engine="c", quoting=3, on_bad_lines="warn")
    extra = df[list(range(3, 8))].notna() & (df[list(range(3, 8))].apply(lambda c: c.str.strip()) != "")
    n_extra = int(extra.any(axis=1).sum())
    ex_rows = df.loc[extra.any(axis=1)].head(3).fillna("").astype(str)
    extra_examples = [" | ".join(r) for r in ex_rows.values.tolist()]
    df = df[[0, 1, 2]].rename(columns={0: "ts", 1: "sensor", 2: "state"})
    bad = extra_examples
    n_raw = len(df)
    df["ts"] = pd.to_datetime(df["ts"].str.strip(), format="ISO8601", errors="coerce")
    n_badts = int(df["ts"].isna().sum())
    df = df.dropna(subset=["ts"])
    df["sensor"] = df["sensor"].str.strip(); df["state"] = df["state"].str.strip()
    n_unsorted = int((df["ts"].diff().dt.total_seconds() < 0).sum())
    df = df.sort_values("ts", kind="stable")
    n_dup = int(df.duplicated().sum())
    df = df.drop_duplicates().reset_index(drop=True)
    df["sensor"] = df["sensor"].astype("category"); df["state"] = df["state"].astype("category")
    pq.write_table(pa.Table.from_pandas(df, preserve_index=False), f"{OUT}/{home}.parquet", compression="zstd")
    inv = df.groupby("sensor", observed=True).agg(n=("ts", "size"), first=("ts", "min"), last=("ts", "max")).reset_index()
    st = df.groupby("sensor", observed=True)["state"].unique().map(lambda a: "|".join(sorted(map(str, a))))
    inv["states"] = inv["sensor"].map(st)
    inv.insert(0, "home", home)
    days = df["ts"].dt.normalize().nunique()
    idx = dict(home=home, source_zip=zname, n_raw_lines=n_raw, n_events=len(df),
               n_bad_rows=n_extra, n_bad_ts=n_badts, n_unsorted=n_unsorted, n_exact_dup=n_dup,
               start=str(df["ts"].min()), end=str(df["ts"].max()),
               span_days=round((df["ts"].max() - df["ts"].min()).total_seconds() / 86400, 1),
               days_with_data=int(days), n_sensors=int(df["sensor"].nunique()),
               bad_examples=json.dumps(bad[:3]))
    return idx, inv

if __name__ == "__main__":
    os.makedirs(OUT, exist_ok=True); os.makedirs("data/_meta", exist_ok=True)
    job = json.load(open(sys.argv[1]))[int(sys.argv[2])]
    idx, inv = convert(job[:4])
    json.dump(idx, open(f"data/_meta/{idx['home']}.json", "w"))
    inv.to_csv(f"data/_meta/{idx['home']}_inv.csv", index=False)
