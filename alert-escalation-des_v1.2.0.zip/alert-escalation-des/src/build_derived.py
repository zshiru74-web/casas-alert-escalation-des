"""Build benign alert streams and fall library for one detection-parameter setting.
usage: python build_derived.py <outdir> <buffer> <window> <stat>   (stat = max | 0.99 ...)"""
import sys, os, json, numpy as np, pandas as pd
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import pipeline_events as pe

out, buffer, win, stat = sys.argv[1], float(sys.argv[2]), int(sys.argv[3]), sys.argv[4]
stat = stat if stat == "max" else float(stat)
meta = json.load(open("data/derived/meta.json")); INCL = meta["homes"]
HOMES = {h: pe.Home(h) for h in INCL}
det, pp = {}, {}
for h in INCL:
    d = pe.Detector(HOMES[h], "personal", buffer=buffer, win=win)
    if stat != "max":
        d.T = HOMES[h].e2_profiles(buffer, win, stat=stat)
    det[(h, "personal")] = d; pp[h] = np.nanmedian(d.T[pe.BURN:], axis=0)
for h in INCL:
    gp = np.nanmedian(np.vstack([pp[o] for o in INCL if o != h]), axis=0)
    det[(h, "generic")] = pe.Detector(HOMES[h], "generic", generic_profile=gp)
os.makedirs(out, exist_ok=True)
for cfg in ["generic", "personal"]:
    pd.concat([det[(h, cfg)].benign_alerts() for h in INCL], ignore_index=True).to_parquet(f"{out}/benign_{cfg}.parquet", index=False)
def redetect(base):   # same fall moments as the main analysis, detection under this setting
    rows = []
    for h, j in zip(base.home.values, base.j.values):
        rec = {}
        for cfg in ["generic", "personal"]:
            dl, rule = det[(h, cfg)].fall_detection(int(j)); rec[f"det_{cfg}"] = dl; rec[f"rule_{cfg}"] = rule
        rows.append(rec)
    return base.drop(columns=[c for c in base.columns if c.startswith(("det_", "rule_"))]).join(pd.DataFrame(rows))


redetect(pd.read_parquet("data/derived/fall_library.parquet")).to_parquet(f"{out}/fall_library.parquet", index=False)
redetect(pd.read_parquet("data/derived/fall_library_day.parquet")).to_parquet(f"{out}/fall_library_day.parquet", index=False)
json.dump(meta, open(f"{out}/meta.json", "w"))
