"""Stage B/C of the trace-driven pipeline: thresholds, causal alert generation,
and the fall library.  Inputs are produced by stage A (data/activity, data/episodes).

Detection configurations
  fixed    : E1 night bathroom >= 30 min; E2 inactivity >= 180 min, active only 08:00-20:00
             (time-of-day profile); E3 night exit >= 30 min.
  generic  : E1 30 min; E2 24-h time-of-day profile = leave-one-home-out median of the other
             homes' personal profiles; E3 30 min.
  personal : outcome-informed adaptive thresholds. E1/E3 = max(30, P99 of the resident's own
             episodes in the previous 60 valid days); E2 24-h profile = 1.2 x max of the
             resident's own inactivity at the same time of day (+-30 min) in the previous 60
             valid days (Cuddihy et al., 2007), floor 60 min.
All rules are causal: only information available at the alert time is used.
"""
import numpy as np, pandas as pd

NS_MIN = 60 * 10**9
NS_DAY = 86400 * 10**9
BURN, WIN = 60, 60
FLOOR_E1, FLOOR_E2, FLOOR_E3 = 30.0, 60.0, 30.0
Q13, BUFFER = 0.99, 1.2
LOC = {"Bathroom": 0, "Bedroom": 1, "Kitchen": 2, "Living": 3, "Entry": 4}
NO_DOOR_HOMES = {"hh122", "rw106", "rw107", "mv001"}


def dayns(v):
    return v - (v % NS_DAY)


def is_night_ns(v):
    h = (v - dayns(v)) / 3.6e12
    return (h >= 22) | (h < 6)


class Home:
    def __init__(self, h, root="data"):
        self.h = h
        days = pd.read_parquet(f"{root}/episodes/{h}_days.parquet")
        vd = days[days.valid].sort_values("day").reset_index(drop=True)
        vd["vidx"] = np.arange(len(vd)); vd["eval"] = vd.vidx >= BURN
        self.vd = vd
        self.vdays = vd.day.values.astype("datetime64[ns]").astype("int64")
        self.vidx = {int(d): i for i, d in enumerate(self.vdays)}
        self.evalset = set(int(d) for d in self.vdays[BURN:])
        self.dok = {int(pd.Timestamp(d).value): bool(o) for d, o in zip(days.day, days.door_ok)}
        a = pd.read_parquet(f"{root}/activity/{h}.parquet")
        m = a[a.kind == 0]
        self.mt = m.ts.values.astype("datetime64[ns]").astype("int64"); self.ml = m["loc"].values
        self.do = a.loc[a.kind == 1, "ts"].values.astype("datetime64[ns]").astype("int64")
        self.gaps = pd.read_parquet(f"{root}/episodes/{h}_gaps.parquet")
        self.bath = pd.read_parquet(f"{root}/episodes/{h}_bath.parquet")
        self.nx = pd.read_parquet(f"{root}/episodes/{h}_nightexit.parquet")
        self.M = self._di_marks()

    # ---- inactivity duration (DI) at 30-min marks of each valid day (causal, in-home only)
    def _di_marks(self):
        marks = (self.vdays[:, None] + np.arange(48) * 30 * NS_MIN).ravel()
        k = np.searchsorted(self.mt, marks, side="right") - 1
        kk = np.clip(k, 0, None)
        last = self.mt[kk]; lastloc = self.ml[kk]
        di = (marks - last) / NS_MIN
        nd = np.searchsorted(self.do, marks, side="left") - np.searchsorted(self.do, last, side="right")
        dk = np.repeat(np.array([self.dok.get(int(d), False) for d in self.vdays]), 48)
        away = np.where(dk, nd > 0, lastloc == LOC["Entry"])
        # censor marks whose current gap reaches back to a non-valid day (data outage / no record)
        lastday = dayns(last); markday = dayns(marks)
        vset = np.array(sorted(self.vidx)); pos_last = np.searchsorted(vset, lastday); pos_mark = np.searchsorted(vset, markday)
        last_valid = (pos_last < len(vset)) & (vset[np.clip(pos_last, 0, len(vset) - 1)] == lastday)
        contiguous = (markday - lastday) == (pos_mark - pos_last) * NS_DAY   # no invalid day in between
        di[away | (k < 0) | ~last_valid | ~contiguous] = np.nan
        return di.reshape(len(self.vdays), 48)

    def e2_profiles(self, buffer=BUFFER, win=WIN, stat="max"):
        M = self.M; n = M.shape[0]; T = np.full((n, 48), np.nan)
        Mp = np.concatenate([M[:, -1:], M, M[:, :1]], axis=1)
        for i in range(min(win, BURN), n):
            W = Mp[max(0, i - win):i]   # expanding window until `win` days of history exist
            s = np.concatenate([W[:, 0:48], W[:, 1:49], W[:, 2:50]], axis=0)
            base = np.nanmax(s, axis=0) if stat == "max" else np.nanquantile(s, stat, axis=0)
            T[i] = np.maximum(FLOOR_E2, buffer * base)
        return T

    @staticmethod
    def rolling_q(ev_t, ev_dur, vdays, floor, q=Q13, win=WIN):
        thr = {}
        dd = dayns(ev_t); o = np.argsort(dd); dd = dd[o]; du = ev_dur[o]
        for i in range(BURN, len(vdays)):
            s0, s1 = np.searchsorted(dd, vdays[max(0, i - win)]), np.searchsorted(dd, vdays[i])
            w = du[s0:s1]
            thr[int(vdays[i])] = max(floor, float(np.quantile(w, q))) if len(w) >= 10 else floor
        return thr


def e2_first_cross(ts, tend, thr_fn, floor_min=FLOOR_E2, horizon_min=48 * 60):
    """First t in (ts, min(tend, ts+horizon)) with t - ts >= thr(t).
    The 48-h horizon equals the detection horizon of a fall (Table 2); version 1.1.0 and earlier searched only 24 h."""
    t = ts + int(floor_min * NS_MIN); lim = min(tend, ts + int(horizon_min * NS_MIN))
    while t < lim:
        d = dayns(t); b = int((t - d) // (30 * NS_MIN)); b1 = d + (b + 1) * 30 * NS_MIN
        th = thr_fn(d, b)
        if th == th:
            cand = max(t, ts + int(th * NS_MIN))
            if cand < min(b1, lim):
                return cand
        t = b1
    return None


def fixed_window_alert(ts, tend, theta=180.0, w0=8.0, w1=20.0, horizon_min=48 * 60):
    """Conventional daytime rule: inactivity counted only inside [w0, w1); alert when it reaches theta."""
    lim = min(tend, ts + int(horizon_min * NS_MIN)); d = dayns(ts)
    while d < lim:
        start = max(ts, d + int(w0 * 60 * NS_MIN)); cand = start + int(theta * NS_MIN)
        if cand < d + int(w1 * 60 * NS_MIN) and cand < lim:
            return cand
        d += NS_DAY
    return None


FIXED_PROFILE = np.array([180.0 if 16 <= b < 40 else np.nan for b in range(48)])


class Detector:
    """Holds the thresholds of one home under one configuration."""
    def __init__(self, home, config, generic_profile=None, buffer=BUFFER, win=WIN):
        self.H = home; self.config = config
        H = home
        if config == "personal":
            self.T = H.e2_profiles(buffer, win)
            bn = H.bath[H.bath.night]
            self.thr1 = Home.rolling_q(bn.t_s.values.astype("int64"), bn.dur.values, H.vdays, FLOOR_E1, win=win)
            if len(H.nx):
                self.thr3 = Home.rolling_q(H.nx.t_o.values.astype("datetime64[ns]").astype("int64"),
                                           H.nx.dur.fillna(1e9).values, H.vdays, FLOOR_E3, win=win)
            else:
                self.thr3 = {}
        else:
            prof = FIXED_PROFILE if config == "fixed" else generic_profile
            self.T = np.tile(prof, (len(H.vdays), 1)); self.T[:BURN] = np.nan
            self.thr1 = {int(d): FLOOR_E1 for d in H.vdays[BURN:]}
            self.thr3 = {int(d): FLOOR_E3 for d in H.vdays[BURN:]}
        self.floor2 = 180.0 if config == "fixed" else FLOOR_E2

    def thr2(self, d, b):
        i = self.H.vidx.get(d)
        return self.T[i, b] if i is not None else np.nan

    def e2_alert(self, ts, tend, lastloc, observed_trace=True):
        H = self.H; d0 = dayns(ts)
        door_ok = H.dok.get(d0, False)
        if not door_ok and lastloc == LOC["Entry"]:
            return None  # system cannot distinguish an exit from inactivity
        if door_ok and observed_trace:   # in a fall counterfactual no later door event occurs
            k = np.searchsorted(H.do, ts, side="right")
            if k < len(H.do) and H.do[k] < tend:
                tend = H.do[k]
        if self.config == "fixed":
            return fixed_window_alert(ts, tend)
        return e2_first_cross(ts, tend, self.thr2, self.floor2)

    # ---- benign alert stream on evaluation days
    def benign_alerts(self):
        H = self.H; out = []
        g = H.gaps[H.gaps.dur >= min(self.floor2, FLOOR_E2)]
        for ts, te, ll in zip(g.t_s.values.astype("datetime64[ns]").astype("int64"),
                              g.t_e.values.astype("datetime64[ns]").astype("int64"), g.last_loc.values):
            if dayns(ts) not in H.evalset:
                continue
            ta = self.e2_alert(ts, te, ll)
            if ta is not None and dayns(ta) in H.vidx:
                out.append(("E2", ta))
        bn = H.bath[H.bath.night]
        for ts, du in zip(bn.t_s.values.astype("datetime64[ns]").astype("int64"), bn.dur.values):
            d0 = dayns(ts)
            if d0 not in H.evalset:
                continue
            th = self.thr1[d0]
            if du >= th:
                ta = ts + int(th * NS_MIN)
                if dayns(ta) in H.vidx:
                    out.append(("E1", ta))
        if len(H.nx):
            for to, du in zip(H.nx.t_o.values.astype("datetime64[ns]").astype("int64"), H.nx.dur.fillna(1e9).values):
                d0 = dayns(to)
                if d0 not in H.evalset or not H.dok.get(d0, False):
                    continue
                th = self.thr3.get(d0, FLOOR_E3)
                if du >= th:
                    ta = to + int(th * NS_MIN)
                    if dayns(ta) in H.vidx:
                        out.append(("E3", ta))
        df = pd.DataFrame(out, columns=["type", "t_alert_ns"])
        df["home"] = H.h
        df["vday"] = [H.vidx[dayns(v)] for v in df.t_alert_ns]
        df["min_of_day"] = (df.t_alert_ns - dayns(df.t_alert_ns.values)) / NS_MIN
        return df

    # ---- detection delay of a fall that occurs at motion event index j
    def fall_detection(self, j):
        H = self.H; tf = H.mt[j]; loc = H.ml[j]
        tvs = None
        if loc == LOC["Bathroom"]:
            i = j   # start of the bathroom visit containing this event
            while i > 0 and H.ml[i - 1] == LOC["Bathroom"]:
                i -= 1
            tvs = H.mt[i]
        return self.detect_fall_at(tf, loc, tvs)

    def detect_fall_at(self, tf, loc, tvs=None):
        """Ambient detection delay (min) and rule for a fall at time tf (ns) in room loc.
        tvs: start of the bathroom visit in progress (ns) or None.
        E1 fires once per visit, when the stay reaches theta1. If the fall occurs at or before that moment,
        the E1 alert detects it; if the fall occurs later, the visit's E1 alert has already been raised and
        handled before the fall and is not raised again, so the fall must be detected by E2."""
        H = self.H; cands = {}
        ta = self.e2_alert(tf, tf + 48 * 60 * NS_MIN, loc, observed_trace=False)
        if ta is not None:
            cands["E2"] = ta
        if loc == LOC["Bathroom"] and tvs is not None and is_night_ns(tvs) and dayns(tvs) in H.vidx:
            t_e1 = tvs + int(self.thr1.get(dayns(tvs), FLOOR_E1) * NS_MIN)
            if tf <= t_e1:
                cands["E1"] = t_e1
        if not cands:
            return None, None
        k = min(cands, key=cands.get)
        return (cands[k] - tf) / NS_MIN, k
