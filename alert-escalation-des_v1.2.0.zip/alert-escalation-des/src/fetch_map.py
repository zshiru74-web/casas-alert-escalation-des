
import sys, io, json, zipfile, requests, time, pandas as pd
class HTTPRangeFile(io.RawIOBase):
    def __init__(self,url):
        h=requests.head(url,allow_redirects=True,timeout=60); self.url=h.url
        self.size=int(h.headers["Content-Length"]); self.pos=0
    def seekable(self): return True
    def readable(self): return True
    def tell(self): return self.pos
    def seek(self,off,whence=0):
        self.pos={0:off,1:self.pos+off,2:self.size+off}[whence]; return self.pos
    def read(self,n=-1):
        if n<0: n=self.size-self.pos
        if n==0 or self.pos>=self.size: return b""
        end=min(self.pos+n,self.size)-1
        for k in range(5):
            try:
                r=requests.get(self.url,headers={"Range":f"bytes={self.pos}-{end}"},timeout=300)
                if r.status_code==206: break
            except Exception: time.sleep(5)
        assert r.status_code==206
        self.pos=end+1; return r.content
    def readinto(self,b):
        d=self.read(len(b)); b[:len(d)]=d; return len(d)
url, home = sys.argv[1], sys.argv[2]
zr=zipfile.ZipFile(io.BufferedReader(HTTPRangeFile(url),buffer_size=8<<20))
with zr.open(f"data/{home}.csv") as fh: b=fh.read()
first=b[:200].split(b"\n")[0]
sep="," if b"," in first else r"\s+"
mp=pd.read_csv(io.BytesIO(b),sep=sep,header=None,names=list(range(10)),dtype=str,engine="c",on_bad_lines="skip")
for c in range(4): mp[c]=mp[c].str.strip()
nbad_fields=int(mp[3].isna().sum()); bad_examples=mp[mp[3].isna()].head(3).fillna("").astype(str).values.tolist()
mp=mp[mp[3].notna()].rename(columns={0:"date",1:"time",2:"sensor",3:"state"})
mp["ts"]=pd.to_datetime(mp.date+" "+mp.time,format="ISO8601"); mp=mp[["ts","sensor","state"]]
n_map_raw=len(mp); mp=mp.drop_duplicates()
rawd=pd.read_parquet(f"data/homes/{home}.parquet"); rawd["sensor"]=rawd.sensor.astype(str); rawd["state"]=rawd.state.astype(str)
j=rawd.merge(mp,on=["ts","state"],how="inner",suffixes=("_raw","_map"))
ku=j.groupby(["ts","state"]).size(); uniq=ku[ku==1].index
ju=j.set_index(["ts","state"]).loc[uniq].reset_index()
tab=ju.groupby(["sensor_raw","sensor_map"]).size().rename("n").reset_index()
tab["share"]=tab.n/tab.groupby("sensor_raw").n.transform("sum")
tab.insert(0,"home",home); tab.to_csv(f"data/sensor_map/{home}.csv",index=False)
stats=dict(home=home,n_raw=len(rawd),n_mapped_file=n_map_raw,n_mapped_dedup=len(mp),n_joined=len(j),n_unique_keys=len(uniq),
           raw_sensors=int(rawd.sensor.nunique()),raw_sensors_aligned=int(tab.sensor_raw.nunique()),
           n_short_rows=nbad_fields,short_examples=bad_examples,min_share=float(tab.groupby("sensor_raw").share.max().min()))
json.dump(stats,open(f"data/sensor_map/{home}.json","w"))
